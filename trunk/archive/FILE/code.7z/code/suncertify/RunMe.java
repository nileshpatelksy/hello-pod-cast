package suncertify;

import suncertify.mvc.*;
import suncertify.server.*;

/**
 * Class <code>RunMe</code> is the entry of the application.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public final class RunMe {

    private RunMe() {}

    /**
     * Launches the application, and selects which mode to enter.
     *
     * @param args the mode with choice for entering. "alone" for alone mode,
     * "server" for Server of server mode, space or null for Client of server
     * mode.
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            new ServiceViewImpl(false);     // entry of server mode for Client
        } else if (args.length == 1) {
            if(args[0].equals("server")) {
                new ServiceServer();        // entry of server mode for Server
            } else if(args[0].equals("alone")) {
                new ServiceViewImpl(true);  // entry of alone mode.
            } else {
                System.out.println("Invalid command flag, "
                                   + "please input again.");
            }
        } else {
            System.out.println("wrong command flag, please input again");
        }
    }
}