package suncertify.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 * Class <code>CoreUserInterface</code> is core GUI of the application,
 * both at alone mode and at server mode. User can operate database
 * file through the GUI, and database information is displayed in a table
 * on it.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class CoreUserInterface extends JFrame {
    private Container container;
    private GridBagLayout gbLayout;
    private GridBagConstraints gbConstraints;

    private JTable resultTable;
    private JScrollPane scorllPane;

    private JCheckBox name;
    private JCheckBox location;
    private JCheckBox specialty;
    private JCheckBox size;
    private JCheckBox rate;
    private JCheckBox owner;

    private JTextField nameField;
    private JTextField locationField;
    private JTextField specialtyField;
    private JTextField sizeField;
    private JTextField rateField;
    private JTextField ownerField;

    private JButton query;
    private JButton book;
    private JButton add;
    private JButton delete;
    private JButton modify;
    private JButton reset;

    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenuItem openItem;
    private JMenuItem exitItem;

    private JLabel statusBar;

    private InfoTableModel infoTableModel;

    /**
     * Constructs core user interface for operating database file and
     * displaying specified records.
     */
    public CoreUserInterface() {
        super("Core User Interface");

        infoTableModel = new InfoTableModel();
        resultTable = new JTable();

        menuBar = new JMenuBar();
        fileMenu = new JMenu("File");
        openItem = new JMenuItem("Open Database File...");
        exitItem = new JMenuItem("Exit");

        setJMenuBar(menuBar);
        menuBar.add(fileMenu);
        fileMenu.add(openItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        container = getContentPane();
        gbLayout = new GridBagLayout();
        gbConstraints = new GridBagConstraints();
        container.setLayout(gbLayout);	

        resultTable = new JTable();
        scorllPane = new JScrollPane(resultTable);

        name = new JCheckBox("Name");
        location = new JCheckBox("Location");

        // The next four JCheckBox instances are prepared
        // for future upgrading, but now are not enabled.
        specialty = new JCheckBox("Specialties");
        specialty.setEnabled(false);
        size = new JCheckBox("Size");
        size.setEnabled(false);
        rate = new JCheckBox("Rate");
        rate.setEnabled(false);
        owner = new JCheckBox("Owner");
        owner.setEnabled(false);

        nameField = new JTextField();
        locationField = new JTextField();

        // The next four JTextField instances are prepared
        // for future upgrading, but now are not enabled.
        specialtyField = new JTextField();
        specialtyField.setEnabled(false);
        sizeField = new JTextField();
        sizeField.setEnabled(false);
        rateField = new JTextField();
        rateField.setEnabled(false);
        ownerField = new JTextField();
        ownerField.setEnabled(false);

        query = new JButton("Query");
        book = new JButton("Book");

        // The next three JButton instances are prepared
        // for future upgrading, but now are not enabled.
        add = new JButton("Add");
        add.setEnabled(false);
        delete = new JButton("Delete");
        delete.setEnabled(false);
        modify = new JButton("Modify");
        modify.setEnabled(false);
        
        reset = new JButton("Reset");

        statusBar = new JLabel("Welcome to book service!");

        gbConstraints.fill = GridBagConstraints.HORIZONTAL;

        gbConstraints.weightx = 0;
        addComponent(name, 0, 0, 1, 1);
        addComponent(location, 0, 2, 1, 1);
        addComponent(specialty, 1, 0, 1, 1);
        addComponent(size, 1, 2, 1, 1);
        addComponent(rate, 2, 0, 1, 1);
        addComponent(owner, 2, 2, 1, 1);

        gbConstraints.weightx = 100;
        addComponent(nameField, 0, 1, 1, 1);
        addComponent(locationField, 0, 3, 1, 1);
        addComponent(specialtyField, 1, 1, 1, 1);
        addComponent(sizeField, 1, 3, 1, 1);
        addComponent(rateField, 2, 1, 1, 1);
        addComponent(ownerField, 2, 3, 1, 1);

        addComponent(query, 0, 4, 1, 1);
        addComponent(book, 0, 5, 1, 1);
        addComponent(add, 1, 4, 1, 1);
        addComponent(delete, 1, 5, 1, 1);
        addComponent(modify, 2, 4, 1, 1);
        addComponent(reset, 2, 5, 1, 1);

        gbConstraints.fill = GridBagConstraints.BOTH;
        gbConstraints.weightx = 100;
        gbConstraints.weighty = 100;
        addComponent(scorllPane, 3, 0, 6, 1);

        gbConstraints.fill = GridBagConstraints.HORIZONTAL;
        gbConstraints.weightx = 0;
        gbConstraints.weighty = 0;
        addComponent(statusBar, 4, 0, 6, 1);	
    }

    // Adds GUI components to JContentPane which uses GridBayLayout.
    private void addComponent(Component c, int row, int column,
                              int width, int height)
    {
        gbConstraints.gridx = column;
        gbConstraints.gridy = row;

        gbConstraints.gridwidth = width;
        gbConstraints.gridheight = height;

        gbLayout.setConstraints(c, gbConstraints);
        container.add(c);
    }

    /**
     * Displays database infomation in a <code>JTable</code>.
     *
     * @param resultNo an arrary of record numbers which are displayed.
     * @param resultInfos information of records which are displayed.
     */
    public void displayInfo(int[] resultNo, String[][] resultInfos) {
        String[][] newData =
                new String[resultNo.length][7];

        // reads specified records matches user's criteria,
        // and sets them to newData.
        for (int i = 0; i < resultNo.length; i++) {
            newData[i][0] = Integer.toString(resultNo[i] + 1);

            for ( int j = 0; j < 6; j++) {
                newData[i][j + 1] = resultInfos[i][j];	
            }
        }

        infoTableModel.setDataVector(newData,
                infoTableModel.getTableHeaders());
        resultTable.setModel(infoTableModel);
        resultTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        resultTable.getColumnModel().getColumn(1).setPreferredWidth(600);
        resultTable.getColumnModel().getColumn(2).setPreferredWidth(350);
        resultTable.getColumnModel().getColumn(3).setPreferredWidth(600);
        resultTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        resultTable.getColumnModel().getColumn(5).setPreferredWidth(150);
        resultTable.getColumnModel().getColumn(6).setPreferredWidth(200);
    }

    /**
     * Gets <code>JCheckBox</code> instance location's text.
     *
     * @return <code>JCheckBox</code> instance location's text "Location".
     */
    public String getLocationText() {
        return locationField.getText();
    }

    /**
     * Gets <code>JCheckBox</code> instance name's text.
     *
     * @return <code>JCheckBox</code> instance name's text "Name".
     */
    public String getNameText() {
        return nameField.getText();
    }

    /**
     * Gets the number of the record which is selected.
     *
     * @return the number of the record which is selected.
     */
    public int getRecordNo() {
        int selectedRow = resultTable.getSelectedRow();
        String recordNo = (String) infoTableModel.getValueAt(selectedRow, 0);
        Integer recNo = new Integer(recordNo);

        return recNo.intValue();
    }

    /**
     * Sets listeners to <code>CoreUserInterface</code>'s components.
     *
     * @param coreUIListeners the listeners which are used by <code>
     * CoreUserInterface</code>'s components.
     */
    public void setListeners(HashMap coreUIListeners) {
        query.addActionListener(
                (ActionListener) coreUIListeners.get("coreUIQuery"));
        book.addActionListener(
                (ActionListener) coreUIListeners.get("coreUIBook"));
        reset.addActionListener(
                (ActionListener) coreUIListeners.get("coreUIReset"));
        openItem.addActionListener(
                (ActionListener) coreUIListeners.get("coreUIOpen"));
        exitItem.addActionListener(
                (ActionListener) coreUIListeners.get("coreUIExit"));
        addWindowListener(
                (WindowAdapter) coreUIListeners.get("coreUIClose"));
    }

    /**
     * Sets new text on status bar, in order to show the resultant status of
     * user's operation.
     *
     * @param statusText status of user's operations.
     */
    public void setStatusBarText(String statusText) {
        statusBar.setText(statusText);
    }

    /**
     * Shows proper message to user.
     *
     * @param type the type of message to be displayed.
     * @param msg the massage be displayed.
     */
    public void showMessageDialog(String type, String msg) {
        if (type.equals("Error")) {
            JOptionPane.showMessageDialog(this,	msg,
                    "Error", JOptionPane.ERROR_MESSAGE);
        }

        if (type.equals("Message")) {
            JOptionPane.showMessageDialog(this, msg,
                    "Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Selects other database files when at alone mode.
     *
     * @return new database file's absolute path.
     */
    public String getNewFile() {
        String newFile = "";
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.OPEN_DIALOG);

        int fileValue = fileChooser.showOpenDialog(this);

        if (fileValue == JFileChooser.APPROVE_OPTION) {
            newFile = fileChooser.getSelectedFile().getAbsolutePath();
        }

        return newFile;
    }

    /**
     * Tests whether <code>JCheckBox</code> name is selected.
     *
     * @return true, if <code>JCheckBox</code> name is selected;
     * false, otherwise.
     */
    public boolean nameIsSelected() {
        return (name.isSelected() ? true : false);
    }

    /**
     * Tests whether <code>JCheckBox</code> location is selected.
     *
     * @return true, if <code>JCheckBox</code> location is selected;
     * false, otherwise.
     */
    public boolean locationIsSelected() {
        return (location.isSelected() ? true : false);
    }

    /**
     * Resets text fields and check boxes, then user can rewrite them.
     */
    public void reset() {
        name.setSelected(false);
        nameField.setText("");
        location.setSelected(false);
        locationField.setText("");
    }

    /**
     * When at server mode, sets CoreUserInterface's menu item
     * "Open Database File..." unenabled. User can not select other
     * database files at client side when at server mode.
     */
    public void setOpenItemUnenabled() {
        openItem.setEnabled(false);
    }
}