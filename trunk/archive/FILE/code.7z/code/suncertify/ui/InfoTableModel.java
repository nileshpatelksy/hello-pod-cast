package suncertify.ui;

import javax.swing.table.*;

/**
 * Class <code>InfoTableModel</code> is used to display the records of
 * database file.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class InfoTableModel extends DefaultTableModel {

    // the head of this table.
    private String[] headers = {"No.", "Name", "Location", 
                                "Specialties", "Size", "Rate", "Owner"};

    private String[][] rowData;

    public InfoTableModel() {}

    /**
     * Gets field names, and show on the head of this table.
     *
     * @return the tableheaders used by this table.
     */
    public String[] getTableHeaders() {
        return headers;
    }

    /**
     * Sets all cells of this table uneditable.
     *
     * @param row the row whose value is to be queried.
     * @param column the column whose value is to be queried.
     * @return false.
     */
    public boolean isCellEditable(int row, int column) {
        return false;
    }
}