package suncertify.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

/**
 * Class <code>ModeSelection</code> is the entry of mode.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class ModeSelection extends JFrame {
    private JLabel dbLabel = new JLabel("Database File");
    private JLabel ipLabel = new JLabel("Host Address");
    private JLabel portLabel = new JLabel("port");

    private JTextField dbField = new JTextField();
    private JTextField ipField = new JTextField("localhost");
    private JTextField portField = new JTextField("1099");

    private JButton open = new JButton("Open...");
    private JButton enter = new JButton("Enter");
    private JButton exit = new JButton("Exit");

    private JPanel abovePanel = new JPanel();
    private JPanel middlePanel = new JPanel();
    private JPanel belowPanel = new JPanel();

    private String dbFileName;
    private boolean isAlone;

    /**
     * Constructs mode selection GUI for selecting dabase files at alone
     * mode, or inputing host address and port at server mode.
     *
     * @param alone true, alone mode is selected; false, server mode is
     * selected.
     */
    public ModeSelection(boolean alone) {
        isAlone = alone;

        Container container = getContentPane();
        container.setLayout(new GridLayout(3, 1));

        if (isAlone) {
            JOptionPane.showMessageDialog(null,
                    "This is alone mode, please select a database file.",
                    "Message", JOptionPane.INFORMATION_MESSAGE);

            setTitle("Alone mode");
        } else {
            JOptionPane.showMessageDialog(null,
                    "This is Client at server mode, "
                    + "please input host address and port.",
                    "Message", JOptionPane.INFORMATION_MESSAGE);

            setTitle("Client in server mode");
        }

        dbField.setColumns(15);
        abovePanel.add(dbLabel);
        abovePanel.add(dbField);
        abovePanel.add(open);

        ipField.setColumns(15);
        portField.setColumns(4);
        middlePanel.add(ipLabel);
        middlePanel.add(ipField);
        middlePanel.add(portLabel);
        middlePanel.add(portField);	

        belowPanel.add(enter);
        belowPanel.add(exit);

        container.add(abovePanel);
        container.add(middlePanel);
        container.add(belowPanel);

        if (alone) {
            ipLabel.setEnabled(false);
            ipField.setEnabled(false);
            portLabel.setEnabled(false);
            portField.setEnabled(false);
        } else {
            dbLabel.setEnabled(false);
            dbField.setEnabled(false);
            open.setEnabled(false);			
        }

        open.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    openFile();
                }
            }
        );
    }

    // Selects a database file, and sets the file's absolute path in
    // dbField.
    private void openFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.OPEN_DIALOG);

        int fileValue = fileChooser.showOpenDialog(this);

        if (fileValue == JFileChooser.APPROVE_OPTION) {
            dbFileName = fileChooser.getSelectedFile().getAbsolutePath();
            dbField.setText(dbFileName);
        }
    }

    /**
     * Gets database file's absolute path for generating <code>Data</code>.
     *
     * @return database file's absolute path.
     */
    public String getFileName() {
        return dbField.getText();
    }

    /**
     * Gets host address for client connecting.
     *
     * @return host address.
     */
    public String getIP() {
        return ipField.getText();
    }

    /**
     * Gets the port of this host using for client connecting.
     *
     * @return the port this host using.
     */
    public String getPort() {
        return portField.getText();
    }

    /**
     * Tests whether it is alone mode.
     *
     * @return true, it is alone mode; false, it is server mode.
     */
    public boolean isAlone() {
        return isAlone;
    }

    /**
     * Sets listeners to <code>ModeSelection</code>'s components.
     *
     * @param modeSelectionListeners the listeners which are used by
     * <code>ModeSelection</code>'s components.
     */
    public void setListeners(HashMap modeSelectionListeners) {
        enter.addActionListener((ActionListener)
                modeSelectionListeners.get("modeSelectionEnter"));
        exit.addActionListener((ActionListener)
                modeSelectionListeners.get("modeSelectionExit"));
        addWindowListener((WindowListener)
                modeSelectionListeners.get("modeSelectionClose"));
    }
}