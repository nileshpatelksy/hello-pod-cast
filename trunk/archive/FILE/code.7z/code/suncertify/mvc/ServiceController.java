package suncertify.mvc;

import java.io.*;
import java.rmi.*;
import suncertify.db.*;

/**
 * Interface <code>ServiceController</code> provides basic control services
 * for the application.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public interface ServiceController {

    /**
     * Called by the <code>ServiceView</code> in response to the
     * "book" button click on the core GUI.
     *
     * @param recNo the number of record which the user wants to book.
     * @param ownerID the ID number of the user.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void bookHandler(int recNo, String ownerID)
            throws RecordNotFoundException, IOException;

    /**
     * Gets Model of MVC design pattern by connect to local database.
     *
     * @param dbFileName database file's absolute path.
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void enterHandler(String dbFileName) throws IOException;

    /**
     * Gets Model part of MVC design pattern by connect to remote database
     * server.
     *
     * @param host remote server's address.
     * @param port the port which the server is using.
     * @throws RemoteException Thrown if the net connection failed.
     * @throws NotBoundException Thrown if an attempt is made to
     * lookup or unbind in the registry a name that has no
     * associated binding. 
     */
    public void enterHandler(String host, int port)
            throws RemoteException, NotBoundException;

    /**
     * Query specified records which match user's criteria.
     *
     * @param criteria the criteria for querying specified records.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     */
    public void queryHandler(String[] criteria) throws RecordNotFoundException;

    /**
     * Initializes the values of <code>JTable</code> when entering <code>
     * CoreUserInterface</code>, and shows all records in the table.
     *
     * @throws RemoteException Thrown if the net connection failed.
     */
    public void infoInitHandler() throws RemoteException;

    /*
     * Closes the database file.
     *
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void closeDataHandler() throws IOException;
}