package suncertify.mvc;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.rmi.*;
import java.util.*;
import suncertify.ui.*;
import suncertify.db.*;

/**
 * Class <code>ServiceViewImpl<code> provides <code>CoreUserInterface</code>
 * functions, implements view part of the MVC design pattern.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class ServiceViewImpl implements ServiceView {
    private ServiceController serviceController;
    private HashMap coreUIListeners = new HashMap();
    private HashMap modeSelectionListeners = new HashMap();
    private CoreUserInterface coreUserInterface;
    private ModeSelection modeSelection;
    private String dbFileName;
    private Criteria criteria = new Criteria();

    /**
     * Constructs the view of the MVC design pattern.
     *
     * @param alone true, for alone mode; false, for server mode.
     */
    public ServiceViewImpl(boolean alone) {
        createModeSelection(alone);
        serviceController = new ServiceControllerImpl(this);
    }

    /**
     * Adds requester to the list of objects to be notified of user gestures
     * entered through a user interface such as a GUI.
     *
     * @param serviceControllerImpl the controller which listens to user
     * gestures.
     */
    public void addUserGestureListener(ServiceController serviceControllerImpl)
    {
        this.serviceController = serviceControllerImpl;
    }

    /**
     * Shows the records which invoked by the controller.
     *
     * @param resultNo an array of record numbers that matches specified
     * user's criteria.
     * @param resultInfo the values of specified records that
     * matches specified user's criteria.
     */
    public void displayInfo(int[] resultNo, String[][] resultInfo) {
        coreUserInterface.displayInfo(resultNo, resultInfo);
    }

    /**
     * Shows messages through <code>JOptionPane</code>.
     *
     * @param style option style.
     * @param msg the message which showed on <code>JOptionPane</code>.
     */
    public void showMessageDialog(String style, String msg) {
        if (style.equals("Error")) {
            JOptionPane.showMessageDialog(coreUserInterface,
                    msg, "Error", JOptionPane.ERROR_MESSAGE);
        }

        if (style.equals("Message")){
            JOptionPane.showMessageDialog(coreUserInterface,
                    msg, "Message", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Sets messages on status bar.
     *
     * @param status the message that represents current status.
     */
    public void setStatusBarText(String status) {
        coreUserInterface.setStatusBarText(status);
    }

    /**
     * Sets the <code>Window</code> at the middle of screen.
     *
     * @param window the <code>Window</code>, such as <code>JFrame</code>, 
     * <code>JDialog</code>, which should be at the middle of screen.
     */
    public void setAtMiddle(Window window) {
        Dimension screenSize =
                Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = window.getSize();

        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }

        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }

        window.setLocation((screenSize.width - frameSize.width) / 2,
                           (screenSize.height - frameSize.height) /2);
    }

    // Closes database file.
    private void closeData() {
       	if (modeSelection.isAlone()) {
           	try {
           	    serviceController.closeDataHandler();
           	} catch (IOException ioe) {
           	    ioe.printStackTrace();
           	}
        }
    }

    /**
     * When in server mode, sets the <code>JMenuItem</code> openItem
     * in core user interface unenabled.
     */
    public void setOpenItemUnenabled() {
        coreUserInterface.setOpenItemUnenabled();
    }

    /**
     * Creates core user interface.
     */
    public void creatCoreUserInterface() {
        coreUserInterface = new CoreUserInterface();
        coreUserInterface.setSize(800, 600);
        setAtMiddle(coreUserInterface);		
        createCoreUIListeners();
        coreUserInterface.setListeners(coreUIListeners);
        coreUserInterface.show();
    }

    /**
     * Creates listeners for core user interface.
     */
    public void createCoreUIListeners() {
        coreUIListeners.put("coreUIQuery", coreUIQuery);
        coreUIListeners.put("coreUIBook", coreUIBook);
        coreUIListeners.put("coreUIReset", coreUIReset);
        coreUIListeners.put("coreUIOpen", coreUIOpen);
        coreUIListeners.put("coreUIExit", coreUIExit);
        coreUIListeners.put("coreUIClose", coreUIClose);
    }

    private ActionListener coreUIQuery = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            if (coreUserInterface.nameIsSelected()) {
                criteria.setCriteria("Name", coreUserInterface.getNameText());
            } else {
                criteria.setCriteria("Name", "");
            }

            if (coreUserInterface.locationIsSelected()) {
                criteria.setCriteria("Location",
                                     coreUserInterface.getLocationText());
            } else {
                criteria.setCriteria("Location", "");
            }

            try {
                serviceController.queryHandler(criteria.getCriteria());
            } catch (RecordNotFoundException ex) {
                ex.printStackTrace();
            }
        }
    };

    private ActionListener coreUIBook = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            int recNo = 0;
            boolean flag = false;
            String ownerID = null;

            try {
                recNo = coreUserInterface.getRecordNo();
            } catch (Exception ex) {
                showMessageDialog("Error", "Please select a record.");

                return;
            }
		
            while(!flag) {
                ownerID = JOptionPane.showInputDialog(coreUserInterface,
                        "Please input your ID (a 8-digit number).", "Input",
                        JOptionPane.INFORMATION_MESSAGE);

                if (ownerID == null) {
                    return;
                }

                if (ownerID.length() == 8) {
                    flag = true;
                } else {
                    showMessageDialog("Error",
                            "It is an invalid ID, please input again.");
                }
            }

            try {
                serviceController.bookHandler(recNo, ownerID);
                serviceController.queryHandler(criteria.getCriteria());
            } catch (IOException ioe) {
                ioe.printStackTrace();
            } catch (RecordNotFoundException rnfe) {
                rnfe.printStackTrace();
            }
        }
    };

    private ActionListener coreUIReset = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            coreUserInterface.reset();	
        }
    };

    private ActionListener coreUIOpen = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            String newFile = coreUserInterface.getNewFile();

            if (!newFile.equals("")) {
                try {
                    serviceController.enterHandler(newFile);
                    serviceController.infoInitHandler();
                } catch (IOException ioe) {
                    System.err.println(ioe);
                }
            }
        }
    };

    private ActionListener coreUIExit = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            closeData();
            System.exit(0);
        }
    };

    private WindowAdapter coreUIClose = new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
            closeData();
            System.exit(0);
        }
    };

    /**
     * Creates <code>JFrame</code> ModeSelection.
     */
    public void createModeSelection(boolean alone) {
        modeSelection = new ModeSelection(alone);
        modeSelection.pack();
        setAtMiddle(modeSelection);
        creatModeSelectionListeners();
        modeSelection.setListeners(modeSelectionListeners);
        modeSelection.setResizable(false);
        modeSelection.show();	
    }

    /**
     * Creates listeners for ModeSelection.
     */
    public void creatModeSelectionListeners() {
        modeSelectionListeners.put("modeSelectionEnter", modeSelectionEnter);
        modeSelectionListeners.put("modeSelectionExit", modeSelectionExit);
        modeSelectionListeners.put("modeSelectionClose", modeSelectionClose);
    }

    private ActionListener modeSelectionEnter = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            if (modeSelection.isAlone()) {				
                dbFileName = modeSelection.getFileName();
                File file = new File(dbFileName);

                if (dbFileName.equals("")) {
                    showMessageDialog(
                            "Error", "Please select a database file.");
                    return;
                } else if (!(file.exists()
                           && file.canRead() && file.canWrite()))
                {
                    showMessageDialog("Error",
                            "The file is non-existent or inaccessable.");
                    return;
                } else {
                    try {
                        serviceController.enterHandler(dbFileName);
                    } catch (IOException ioe) {
                        System.out.println(ioe);
                        return;
                    }
                }

                creatCoreUserInterface();
            } else {
                String host = modeSelection.getIP();
                int port = 1099;

                try {
                    port = new Integer(modeSelection.getPort()).intValue();
                } catch (NumberFormatException nfe) {
                    showMessageDialog("Error", "Invalid port");
                    return;
                }

                try {
                    serviceController.enterHandler(host, port);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                creatCoreUserInterface();
                setOpenItemUnenabled();
            }

            modeSelection.dispose();

            try {
                serviceController.infoInitHandler();
            } catch (RemoteException re) {
                re.printStackTrace();
            }
        }
    };

    private ActionListener modeSelectionExit = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    };

    private WindowAdapter modeSelectionClose = new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
            System.exit(0);
        }
    };
}