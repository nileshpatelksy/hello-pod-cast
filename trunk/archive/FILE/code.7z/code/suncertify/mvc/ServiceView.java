package suncertify.mvc;

import java.awt.*;

/**
 * Interface <code>ServiceView</code> provides the basic view services.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public interface ServiceView {

    /**
     * Adds requester to the list of objects to be notified of user
     * gestures entered through a user interface such as a GUI.
     *
     * @param serviceController the controller which listens to
     * user gestures.
     */
    public void addUserGestureListener(ServiceController serviceController);

    /**
     * Shows the records which invoked by the controller.
     *
     * @param resultNo an array of record numbers that matches specified
     * user's criteria.
     * @param resultInfo the values of specified records that matches
     * specified user's criteria.
     */
    public void displayInfo(int[] resultNo, String[][] resultInfo);

    /**
     * Shows messages through <code>JOptionPane</code>.
     *
     * @param style option style.
     * @param msg the message which showed on <code>JOptionPane</code>.
     */
    public void showMessageDialog(String style, String msg);

    /**
     * Sets messages on status bar.
     *
     * @param status the message that represents current status.
     */
    public void setStatusBarText(String status);

    /**
     * Sets the <code>Window</code> at the middle of screen.
     *
     * @param window the <code>Window</code>, such as <code>JFrame</code>, 
     * <code>JDialog</code>, which should be at the middle of screen.
     */
    public void setAtMiddle(Window window);

    /**
     * When at server mode, sets the <code>JMenuItem</code> openItem
     * in core user interface unenabled.
     */
    public void setOpenItemUnenabled();
}