package suncertify.mvc;

import java.io.*;
import java.rmi.*;
import java.rmi.registry.*;
import suncertify.db.*;
import suncertify.server.*;

/**
 * Class <code>RemoteServiceModel</code> provides database
 * functions for client at server mode and looks up remote server.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class RemoteServiceModel implements ServiceModel {
    private RemoteDBMain remoteData;

    /**
     * Looks up remote server, and gets remote data.
     *
     * @param host the host address of remote server.
     * @param port the port of remote server using.
     */
    public RemoteServiceModel(String host, int port)
            throws RemoteException, NotBoundException
    {
        DataFactory dataFactory = (DataFactory)
                LocateRegistry.getRegistry(host, port).lookup("DataFactory");
        remoteData = (RemoteDBMain) dataFactory.getRemoteData();
    }

    /**
     * Returns an array of record numbers that matches the specified
     * criteria. 
     *
     * @param criteria user's criteria for querying specified records.
     * @return an array of record numbers that matches the
     * specified criteria.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     * @throws RemoteException Thrown if the net connection failed.
     */
    public int[] find(String[] criteria) throws RecordNotFoundException,
                                                RemoteException
    {
        return remoteData.find(criteria);
    }

    /**
     * Reads a record from the file. Returns an array where each
     * element is a record value.
     *
     * @param recNo the number of a record.
     * @return an array where each element is a record value.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     * @throws RemoteException Thrown if the net connection failed.
     */
    public String[] read(int recNo) throws RecordNotFoundException,
                                           RemoteException
    {
        return remoteData.read(recNo);
    }

    /**
     * Modifies the fields of a record. The new value for field n
     * appears in data[n].
     *
     * @param recNo the number of original record.
     * @param dataValue the original record with updated.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     * @throws RemoteException Thrown if the net connection failed.
     */
    public void updata(int recNo, String[] dataValue)
            throws RecordNotFoundException, RemoteException
    {
        remoteData.update(recNo, dataValue);
	
    }

    /**
     * Closes the data file. But at server mode, it is insteaded by
     * closeFactory in class <code>DataFactoryImpl</code>.
     *
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void closeData() throws IOException {}

    /**
     * Locks a record so that it can only be updated or deleted by
     * this client. If the specified record is already locked, the
     * current thread gives up the CPU and consumes no CPU cycles
     * until the record is unlocked.
     *
     * @param recNo the number of a record with locked.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     * @throws RemoteException Thrown if the net connection failed.
     */
    public void lock(int recNo) throws RecordNotFoundException,
                                       RemoteException
    {
        remoteData.lock(recNo);
    }

    /**
     * Releases the lock on a record.
     *
     * @param recNo the number of a record with unlocked.
     * @throws RecordNotFoundException Thrown when a sepified record
     * does not exist or is marked as deleted.
     * @throws RemoteException Thrown if the net connection failed.
     */
    public void unlock(int recNo) throws RecordNotFoundException,
                                         RemoteException
    {
        remoteData.unlock(recNo);
    }
}