package suncertify.mvc;

import java.io.*;
import java.rmi.*;
import suncertify.db.*;

/**
 * Class <code>ServiceControllerImpl</code> implements basic
 * control services for the application.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class ServiceControllerImpl implements ServiceController {
    private Data data;
    private ServiceModel serviceModel;
    private ServiceView serviceView;

    /**
     * Sets the attributes, and adds user gesture listener.
     *
     * @param serviceView view part of MVC pattern which the controller will
     * listens to.
     */
    public ServiceControllerImpl(ServiceView serviceView) {
        this.serviceView = serviceView;
        serviceView.addUserGestureListener(this);
    }

    /**
     * Query specified records which match user's criteria.
     *
     * @param criteriaString the criteria for querying specified records.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void queryHandler(String[] criteriaString)
            throws RecordNotFoundException
    {
        try {
            int resultLength;
            int[] resultNo = serviceModel.find(criteriaString);
            resultLength = resultNo.length;

            if (resultLength < 1) {
                serviceView.showMessageDialog("Message", "No match record.");
                serviceView.setStatusBarText("No match record!");
            }

            String[][] resultInfos = new String[resultLength][6];

            for (int i = 0; i < resultNo.length; i++) {
                resultInfos[i] = serviceModel.read(resultNo[i] + 1);

                for (int j = 0; j < 6; j++) {
                    resultInfos[i][j] = resultInfos[i][j].trim();
                }
            }

            serviceView.displayInfo(resultNo, resultInfos);			
        } catch (RecordNotFoundException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    /**
     * Initializes the values of <code>JTable</code> when entering
     * <code> CoreUserInterface</code>, and shows all records in
     * the table.
     *
     * @throws RemoteException Thrown if the net connection failed.
     */
    public void infoInitHandler() throws RemoteException {
        try {
            queryHandler(new String[] {"", ""});
        } catch (RecordNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Called by the <code>ServiceView</code> in response to the
     * "book" button click on the core GUI.
     *
     * @param recNo the number of record which the user wants to book.
     * @param ownerID the ID number of the user.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void bookHandler(int recNo, String ownerID)
            throws RecordNotFoundException, IOException
    {
        try {
            String[] dataValue = serviceModel.read(recNo);
            serviceModel.lock(recNo);

            if (dataValue[5].trim().equals("")) {
                dataValue[5] = ownerID;
                serviceModel.updata(recNo, dataValue);
                serviceView.showMessageDialog("Message",
                        "You booked a service successfully!");
                serviceView.setStatusBarText("Book successfully!");
            } else {
                serviceView.showMessageDialog("Error",
                        "The service has been booked, "
                        + "please select another one.");
                serviceView.setStatusBarText("Book failed!");
            }

            serviceModel.unlock(recNo);
        } catch (RecordNotFoundException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    /**
     * Gets Model of MVC design pattern by connect to local database.
     *
     * @param dbFileName database file's absolute path.
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void enterHandler(String dbFileName) throws IOException {
        data = new Data(dbFileName);
        serviceModel = new ServiceModelImpl(data);
    }

    /**
     * Gets Model part of MVC design pattern by connect to remote database
     * server.
     *
     * @param host remote server's address.
     * @param port the port which the server is using.
     * @throws RemoteException Thrown if the net connection failed.
     * @throws NotBoundException Thrown if an attempt is made to
     * lookup or unbind in the registry a name that has no
     * associated binding.
     */
    public void enterHandler(String host, int port)
            throws RemoteException, NotBoundException
    {
        serviceModel = new RemoteServiceModel(host, port);
    }

    /*
     * Closes the database file.
     *
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void closeDataHandler() throws IOException {
        serviceModel.closeData();
    }
}