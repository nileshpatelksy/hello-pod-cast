package suncertify.mvc;

import java.io.*;
import java.rmi.*;
import suncertify.db.*;

/**
 * Class <code>ServiceModelImpl</code> implements database functions,
 * as the model of the MVC design pattern.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class ServiceModelImpl implements ServiceModel {
    private Data data;

    /**
     * Constructs a local <code>Data</code> instance by given
     * <code>Data</code> instance.
     *
     * @param data local <code>Data</code> instance.
     */
    public ServiceModelImpl(Data data) {
        this.data = data;
    }

    /**
     * Reads a record from the file. Returns an array where each
     * element is a record value.
     *
     * @param recNo the number of a record.
     * @return an array where each element is a record value.
     * @throws RemoteException Thrown if the net connection failed.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public String[] read(int recNo) throws RemoteException,
                                           RecordNotFoundException
    {
        return data.read(recNo);
    }

    /**
     * Returns an array of record numbers that matches the specified
     * criteria. Field n int the dtabase file is described by
     * criteria[n]. A null value in criteria[n] matches any field
     * value. A non-null value in criteria[a] matches any field
     * value that begins with criterial[n]. (For example, "Fred"
     * matches "Fred" or "Freddy".)
     *
     * @param criteria a criteria for searching specified record.
     * @return an array of record number that match the
     * specified criteria.
     * @throws RemoteException Thrown if the net connection failed.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public int[] find(String[] criteria) throws RemoteException,
                                                RecordNotFoundException
    {
        return data.find(criteria);
    }

    /**
     * Modifies the fields of a record. The new value for field n
     * appears in data[n].
     *
     * @param recNo the number of original record.
     * @param dataValue the original record with updated.
     * @throws RemoteException Thrown if the net connection failed.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void updata(int recNo, String[] dataValue)
            throws RemoteException, RecordNotFoundException
    {
        data.update(recNo, dataValue);
    }

    /**
     * Locks a record so that it can only be updated or deleted by
     * this client. If the specified record is already locked, the
     * current thread gives up the CPU and consumes no CPU cycles
     * until the record is unlocked.
     *
     * @param recNo the number of a record with locked.
     * @throws RemoteExcpetion Thrown if the net connection failed.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void lock(int recNo) throws RemoteException,
                                       RecordNotFoundException
    {
        data.lock(recNo);
    }

    /**
     * Releases the lock on a record.
     *
     * @param recNo the number of a record with unlocked.
     * @throws RemoteExcpetion Thrown if the net connection failed.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void unlock(int recNo) throws RemoteException,
                                         RecordNotFoundException
    {
        data.lock(recNo);
    }

    /**
     * Closes the database file
     *
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void closeData() throws IOException {
        data.close();
    }
}