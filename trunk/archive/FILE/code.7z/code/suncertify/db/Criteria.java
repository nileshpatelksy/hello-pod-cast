package suncertify.db;

/**
 * Class <code>Criteria</code> is user's qeury criteria.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class Criteria {
    private String[] criteria;

    /**
     * Initializes user's criteria with name and location fields are blank.
     */
    public Criteria() {
        criteria = new String[] {"", ""};
    }

    /**
     * Sets new user's criteria for querying.
     *
     * @param fieldName the field of the record.
     * @param fieldValue the value of the field with user's criteria.
     */
    public void setCriteria(String fieldName, String fieldValue) {
        if (fieldName == "Name") {
            criteria[0] = fieldValue;
        }

        if (fieldName == "Location") {
            criteria[1] = fieldValue;
        }
    }

    /**
     * Gets new user's criteria for re-querying.
     *
     * @return new criteria.
     */
    public String[] getCriteria() {
        return criteria;
    }
}