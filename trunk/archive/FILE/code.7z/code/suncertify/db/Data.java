package suncertify.db;

import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 * Class <code>Data</code> implements all functions of database operation.
 * 
 * @author Sha Jiang
 * @version 1.0
 */
public class Data implements DBMain {
    private RandomAccessFile dbFile;
    private String[] fieldName;
    private int[] fieldLength;
    private int fieldNameLength;
    private int fieldNumber;
    private final int MAGICVALUE = 515;
    private int headLength = 6;
    private final int RECORFLENGTH = 183;
    private int recordNumber;

    /**
     * Opens a database file on local host.
     *
     * @param dbFileName the absolate path of the database file.
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public Data(String dbFileName) throws IOException {
        int magic = 0;

        try {						
            dbFile = new RandomAccessFile(dbFileName, "rw");
            magic = dbFile.readInt();		
            fieldNumber = dbFile.readShort();

            fieldName = new String[fieldNumber];
            fieldLength = new int[fieldNumber];

            for (int j = 0; j < fieldNumber; j++) {
                fieldNameLength = dbFile.readByte();			
                byte[] b = new byte[fieldNameLength];
                dbFile.read(b);
                fieldName[j] = new String(b);
                fieldLength[j] = dbFile.readByte();

                headLength = headLength + fieldNameLength + 2;
            }

                recordNumber =
                        (int) ((dbFile.length() - headLength) / RECORFLENGTH);

        } catch(IOException e) {
            e.printStackTrace();
        }

        if (magic != MAGICVALUE) {
            JOptionPane.showMessageDialog(null, "Invalid database file.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            throw new IOException("Invalid database file.");
        }
    }

    /**
     * Sets the file-pointer at the top of a record.
     *
     * @param recNo the number of a record with seeked.
     */
    public void seekRecord(int recNo) {
        try {
            dbFile.seek(headLength + (recNo - 1) * RECORFLENGTH);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    /**
     * Reads a record from the file. Returns an array where each
     * element is a record value.
     *
     * @param recNo the number of a record.
     * @return an array where each element is a record value.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public String[] read(int recNo) throws RecordNotFoundException {
        String[] record = new String[fieldNumber];
        byte[][] buffer = new byte[fieldNumber][];

        seekRecord(recNo);

        try {
            dbFile.read();
        } catch(IOException e) {
            System.err.println(e);
        }

        for (int i = 0; i < fieldNumber; i++) {
            buffer[i] = new byte[fieldLength[i]];

            try {
                dbFile.read(buffer[i]);
            } catch(IOException e) {
                System.err.println(e);
            }

            record[i] = new String(buffer[i]);
        }

        return record;
    }

    /**
     * Modifies the fields of a record. The new value for field n
     * appears in data[n].
     *
     * @param recNo the number of original record.
     * @param data the original record with updated.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void update(int recNo, String[] data)
            throws RecordNotFoundException
    {
        try {
            seekRecord(recNo);
            dbFile.readByte();
            byte[][] buffer = new byte[fieldNumber][];

            for (int i = 0; i < fieldNumber; i++) {
                buffer[i] = data[i].getBytes();
                dbFile.write(buffer[i]);
            }
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    /**
     * Deletes a record, making the record number and associated disk
     * storage available for reuse. But now is not implemented.
     *
     * @param recNo the number of original record.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void delete(int recNo) throws RecordNotFoundException {}

    /**
     * Returns an array of record numbers that match the specified
     * criteria. Field n int the dtabase file is described by
     * criteria[n]. A null value in criteria[n] matches any field
     * value. A non-null value in criteria[a] matches any field
     * value that begins with criterial[n]. (For example, "Fred"
     * matches "Fred" or "Freddy".)
     *
     * @param criteria a criteria for searching specified record.
     * @return an array of record number that match the
     * specified criteria.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public int[] find(String[] criteria) throws RecordNotFoundException {
        ArrayList buffer = new ArrayList();
        String[][] dataValue = new String[recordNumber][];

        try {
            for (int i = 0; i < recordNumber; i++) {
                if (!isExistent(i + 1)) {
                    continue;
                }

                dataValue[i] = this.read(i + 1);

                if (!isMatch(dataValue[i], criteria)) {
                    continue;
                }

                buffer.add(new Integer(i));
            }
        } catch (RecordNotFoundException e) {
            System.err.println(e);
        }

        int[] numbers = new int[buffer.size()];

        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = ((Integer) buffer.get(i)).intValue();
        }

        return numbers;
    }

    /**
     * Tests a record whether matches user's criteria.
     *
     * @return true, matches user's criteria; false, otherwise.
     */
    public boolean isMatch(String[] value, String[] criteria) {
        boolean isMatch = (
                (criteria[0].equals("") || criteria[0].equalsIgnoreCase(
                        value[0].substring(0, criteria[0].length())))
                && (criteria[1].equals("") || criteria[1].equalsIgnoreCase(
                        value[1].substring(0, criteria[1].length()))));

        return (isMatch ? true : false);
    }

    /**
     * Tests whether a record exists.
     *
     * @param recNo the No. of a record with tested.
     * @return ture, if the record exists; false, otherwise.
     */
    public boolean isExistent(int recNo) {
        boolean isExistent = true;

        try {
            seekRecord(recNo);
            int flag = dbFile.read();

            if (flag == 0) {
                isExistent = true;
            } else {
                isExistent = false;
            }
        } catch (IOException e) {
            System.err.println(e);
        }

        return isExistent;
    }

    /**
     * Creates a new record in the database (possibly reusing a
     * deleted entry). Inserts the given data, and returns the record
     * number of the new record. But now, it is not implemented.
     *
     * @param data the new record.
     * @return the number of the new record.
     * @throws DuplicateKeyException Thrown when attempting to add
     * a duplicate key.
     */
    public int create(String[] data) throws DuplicateKeyException {
        return 5;
    }

    /**
     * Locks a record so that it can only be updated or deleted by
     * this client. If the specified record is already locked, the
     * current thread gives up the CPU and consumes no CPU cycles
     * until the record is unlocked.
     *
     * @param recNo the number of a record with locked.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void lock(int recNo) throws RecordNotFoundException {}

    /**
     * Releases the lock on a record.
     *
     * @param recNo the number of a record with unlocked.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public void unlock(int recNo) throws RecordNotFoundException {}

    /**
     * Determines if a record is currently locked. But I don't use it.
     *
     * @param recNo the number of a record.
     * @return true if the record is locked; false otherwise.
     * @throws RecordNotFoundException Thrown when a specified record
     * does not exist or is marked as deleted.
     */
    public boolean isLocked(int recNo) throws RecordNotFoundException {
        return true;
    }

    /**
     * Closes the database file, flushing any outstanding writes
     * at the same time. Any attempt to access the database after
     * this results in a IOException.
     *
     * @throws IOException Thrown when an I/O wrong occurs.
     */
    public void close() throws IOException {
        dbFile.close();
    }
}