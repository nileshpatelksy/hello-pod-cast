package suncertify.db;

/**
 * Class <code>DuplicateKeyException</code> is subclass of <code>Exception
 * </code>, thrown when a record's key is as the same as another's.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class DuplicateKeyException extends Exception {
    public DuplicateKeyException() {}

    public DuplicateKeyException(String msg) {
        super(msg);
    }
}