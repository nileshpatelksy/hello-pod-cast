package suncertify.db;

/**
 * Class <code>RecordNotFoundException</code> is subclass of <code>Exception
 * </code>, thrown when a sepified record does not exist or is marked as
 * deleted in the database file.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class RecordNotFoundException extends Exception {
    public RecordNotFoundException() {}

    public RecordNotFoundException(String msg) {
        super(msg);
    }
}