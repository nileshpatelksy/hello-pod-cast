package suncertify.server;

import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import suncertify.db.*;

/**
 * Class <code>DataFactoryImpl</code> implements function to
 * generate remote data.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class DataFactoryImpl extends UnicastRemoteObject
                             implements DataFactory
{
    LockManager lockManager = new LockManager();
    Data data;

    /**
     * Sets a local <code>Data</code> instance.
     *
     * @param data local instance of <code>Data</code>
     * @throws RemoteException Thrown when net connection failed.
     */
    public DataFactoryImpl(Data data) throws RemoteException {
        this.data = data;
    }

    /**
     * Gets the data of server side.
     *
     * @return the remote data.
     * @throws RemoteException Thrown when net connection failed.
     */
    public RemoteDBMain getRemoteData() throws RemoteException {
        return new RemoteData(data, lockManager);
    }

    /**
     * Close the data factory of server side.
     *
     * @throws RemoteException Thrown when net connection failed.
     * @throws IOException Thrown when an I/O wrong occurs.
    */
    public void closeFactory() throws RemoteException, IOException {
        data.close();
    }
}