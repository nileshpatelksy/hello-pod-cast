package suncertify.server;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.rmi.*;
import java.rmi.registry.*;
import suncertify.db.*;

/**
 * Class <code>ServiceServer</code> is the Sever at server mode.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public final class ServiceServer extends JFrame {
    private Data data;
    private DataFactory dataFactory;
    private int port;
    private Registry registry;
    private String dbFile;

    private JLabel dbLabel;
    private JLabel portLabel;

    private JTextField dbField;
    private JTextField portField;

    private JButton open;
    private JButton start;
    private JButton exit;

    private JPanel abovePanel = new JPanel();
    private JPanel belowPanel = new JPanel();

    /**
     * Constructs a Server at server mode.
     */
    public ServiceServer() {
        setTitle("Server in server mode");

        Container container = getContentPane();
        container.setLayout(new GridLayout(2, 1));

        JOptionPane.showMessageDialog(null,
                "This is Server at server mode, " +
                "please select a database file and input port.",
                "Message", JOptionPane.INFORMATION_MESSAGE);

        dbLabel = new JLabel("Database File");
        dbField = new JTextField();
        dbField.setColumns(10);
        open = new JButton("Open...");
        portLabel = new JLabel("port");
        portField = new JTextField("1099");
        portField.setColumns(3);

        abovePanel.add(dbLabel);
        abovePanel.add(dbField);
        abovePanel.add(open);
        abovePanel.add(portLabel);
        abovePanel.add(portField);

        start = new JButton("Start");
        exit = new JButton("Exit");
        belowPanel.add(start);
        belowPanel.add(exit);

        container.add(abovePanel);
        container.add(belowPanel);

        pack();
        setAtMiddle();
        setResizable(false);
        show();

        start.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    start();
                }
            }
        );

        open.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    openFile();
                }
            }
        );

        exit.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        stop();
                    } finally {
                        System.exit(0);
                    }
                }
            }
        );

        addWindowListener(
            new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    try {
                        stop();	
                    } finally {
                        System.exit(0);
                    }
                }
            }
        );
    }

    // Selects a database file, and sets the file's absolute path in
    // dbField.
    private void openFile() {
        String dbFileName = "";
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.OPEN_DIALOG);

        int fileValue = fileChooser.showOpenDialog(this);

        if (fileValue == JFileChooser.APPROVE_OPTION) {
            dbFileName = fileChooser.getSelectedFile().getAbsolutePath();
            dbField.setText(dbFileName);
        }
    }

    // Sets the JFrame at the middle of screen.
    private void setAtMiddle() {
        Dimension screenSize =
                Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = this.getSize();

        if (frameSize.height > screenSize.height) {
            frameSize.height = screenSize.height;
        }
        if (frameSize.width > screenSize.width) {
            frameSize.width = screenSize.width;
        }

        setLocation((screenSize.width - frameSize.width) / 2,
                    (screenSize.height - frameSize.height) /2);
    }

    // Loads database file, and starts the Server. 
    private void start() {
        dbFile = dbField.getText();

        try {
            data = new Data(dbFile);
            dataFactory = new DataFactoryImpl(data);
            port = new Integer(portField.getText()).intValue();

            if (registry == null) {
                registry = LocateRegistry.createRegistry(port);
            }
            registry.rebind("DataFactory", dataFactory);

            dbField.setEditable(false);
            open.setEnabled(false);
            portField.setEnabled(false);
            start.setEnabled(false);

            System.out.println("server started");
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Closes DataFactory, and stopes the Server.
    private void stop() {
        try {
            registry.unbind("DataFactory");
            dataFactory.closeFactory();
            System.out.println("server stopped");
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}