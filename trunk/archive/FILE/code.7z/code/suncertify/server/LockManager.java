package suncertify.server;

import java.util.*;

/**
 * Class <code>LockManager</code> provides management of locking.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public class LockManager {
    private long lockCookie;
    private HashMap flag = new HashMap();

    public LockManager() {}

    /**
     * Locks a record so that it can only be updated or deleted by
     * this client. If the specified record is already locked, the
     * current thread gives up the CPU and consumes no CPU cycles
     * until the record is unlocked.
     *
     * @return the object to be associated with the specified recNo.
     * @param recNo the number of a record with locked.
     */
    public synchronized long lock(int recNo) {
        if (flag.containsKey(new Integer(recNo))) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        lockCookie = new Random().nextLong();
        flag.put(new Integer(recNo), new Long(lockCookie));

        return lockCookie;
    }

    /**
     * Releases the lock on a record.
     *
     * @param recNo the number of a record with unlocked.
     */
    public synchronized void unlock(int recNo) {
        if (lockCookie == ((Long) flag.get(new Integer(recNo))).longValue())
        {
            flag.remove(new Integer(recNo));
            this.notify();
        }
    }
}