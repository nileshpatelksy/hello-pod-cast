package suncertify.server;

import java.io.*;
import java.rmi.*;
import suncertify.db.*;

/**
 * Interface <code>DataFactory</code> generates remote data.
 *
 * @author Sha Jiang
 * @version 1.0
 */
public interface DataFactory extends Remote {

    /**
     * Gets the data of server side.
     *
     * @return the remote data.
     * @throws RemoteException Thrown when net connect failed.
     */
    public RemoteDBMain getRemoteData() throws RemoteException;

    /**
     * Close the data factory of server side.
     *
     * @throws RemoteException Thrown when net connection failed.
     * @throws IOException Thrown when accesses file failed.
     */
    public void closeFactory() throws RemoteException, IOException;
}