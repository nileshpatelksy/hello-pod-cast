package com.meadlai.standard.job;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Util {

	public static int c;

	public static void download(String http_url, String name) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		URLConnection urlc = null;
		File file = null;
		FileOutputStream fos = null;
		String abs_name = name;

		// System.out.println("����" + name + "###" + http_url);
		try {
			URL url = new URL(http_url);
			urlc = (URLConnection) url.openConnection();

			if (new File(abs_name).exists()) {
				System.out.println("file exist=:" + abs_name);
				return;
			}

			file = new File(abs_name);
			// System.out.println("file=" + abs_name);
			try {
				file.createNewFile();
			} catch (Exception e) {//				
				file = new File(abs_name);
			}
			fos = new FileOutputStream(file);
			bis = new BufferedInputStream(urlc.getInputStream());
			bos = new BufferedOutputStream(fos);

			int i;
			System.out.println("Downloading...");
			int k =0;
			while ((i = bis.read()) != -1) {
				bos.write(i);
				k++;
				if(k%10000==0){
					System.out.print(">");
				}
			}
			System.out.println(">>$@");
			System.out.println();
			System.out.println("File Success @ " + name);
		} catch (Exception e) {
			// check the file size
			if (file.exists() && file.length() == 0) {
				file.delete();
			}
			e.printStackTrace();
		} finally {
			if (bis != null)
				try {
					bis.close();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			if (bos != null)
				try {
					bos.close();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
		}

	}

	static String getHtml(String i) {

		StringBuffer html = new StringBuffer();
		try {
			URL url = new URL(i);
			URLConnection con = url.openConnection();
			String webpage;
			InputStream in = con.getInputStream();
			while (((c = in.read()) != -1)) {
				int all = in.available();
				byte[] b = new byte[all];
				in.read(b);
				webpage = new String(b, "UTF-8");
				html.append(webpage);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return html.toString();
	}

	// spit url 2 name
	public static String getFileName(String url) {

		// System.out.println("ԭ��" + url);
		int i = url.lastIndexOf('/');
		String name = url.substring(i + 1);
		// System.out.println(i + "�и�" + name);
		i = name.lastIndexOf('.');
		name = name.substring(0, i);

		Pattern p = Pattern.compile("\\d+");
		Matcher m = p.matcher(name);
		if (m.find()) {
			// System.out.println("##" + m.group());
			name = m.group() + "_" + name;
		}

		// System.out.println("FileName=" + name);
		return name;
	}
}
