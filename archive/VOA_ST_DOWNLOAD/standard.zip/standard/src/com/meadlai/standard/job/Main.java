package com.meadlai.standard.job;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main extends Util {

	static void getLinks(String src) {
		Pattern p = Pattern.compile(REGEX);
		Matcher m = p.matcher(src);
		c = 0;
		while (m.find()) {
			if (m.groupCount() <= 0) {
				c++;
				// System.out.println(c + "==" + m.group());
				links.add(m.group());
			}
		}

	}

	private static String cfg_file = "mead.txt";

	public static void init() throws Exception {
		System.out
				.println("*********************************************************");
		System.out
				.println("*********************************************************");
		System.out
				.println("Usage# Open the file <mead.txt> in the same directory.");
		System.out.println("Usage# To alter the configuration.");
		System.out.println("** change the <root> to the folder you wish");
		System.out
				.println("** value <feed>, control the number of feeds you get");
		System.out
				.println("***********************************************************");
		System.out
				.println("*********************************************************");
		System.out.println();
		System.out.println();
		if (!new File(cfg_file).exists()) {
			new File(cfg_file).createNewFile();
			PropertyFileUtil.writeProperties("mead.txt", "feed", ""
					+ GET_NUMBER_DFAULT);
			PropertyFileUtil.writeProperties("mead.txt", "root", DISK_ROOT);
		}

		try {
			String num = PropertyFileUtil.readValue("mead.txt", "feed");
			GET_NUMBER = Integer.parseInt(num);
			DISK_ROOT = PropertyFileUtil.readValue("mead.txt", "root");
		} catch (Exception e) {
			new File(cfg_file).delete();
		}
		File file = new File(DISK_ROOT);
		file.mkdirs();
		// file.createNewFile();
	}

	public static void main(String[] args) throws Exception {
		init();
		if (args != null) {
			if (args.length >= 1) {
				try {
					GET_NUMBER = Integer.parseInt(args[0]);
				} catch (Exception e) {
				}
			}
		}
		Main.getLinks(Main.getHtml(URL_PAGE));
		String inner = null;
		int t = 0;
		for (String l : links) {
			inner = Main.getHtml(URL_ROOT + l);
			Pattern p = Pattern.compile(REGEX_MP3);
			Matcher m = p.matcher(inner);
			if (m.find()) {
				t++;
				// System.out.println(t + "##" + m.group());
			}
			Main.download(URL_ROOT + m.group(), DISK_ROOT + Main.getFileName(l)
					+ ".mp3");
			if (t > GET_NUMBER) {
				break;
			}

		}
		System.out.println();
		System.out.println();
		System.out
				.println("***********************************************************");
		System.out
				.println("*********************************************************");
		System.out.println("Finished All Tasks!");
		System.out
				.println("Usage# Open the file <mead.txt> in the same directory.");
		System.out.println("Usage# To alter the configuration.");
		System.out.println("** change the <root> to the folder you wish");
		System.out
				.println("** value <feed>, control the number of feeds you get");
		System.out
				.println("***********************************************************");
		System.out
				.println("*********************************************************");
		System.out.println();
		System.out.println();
		System.out.println("##care the file path, <separator>=\\\\ ");
		System.out.println("root=C\\:\\\\PodCast\\\\ST_VOA\\");
		System.out.println("##care the file path, <separator>=\\\\ ");
		System.out.println("&&& mp3 files now @" + DISK_ROOT);
	}

	static int GET_NUMBER_DFAULT = 5;
	static String DISK_ROOT = "C:\\PodCast" + File.separator + "ST_VOA"
			+ File.separator;
	static int GET_NUMBER = 5;
	static String URL_FILE;
	static String URL_ROOT = "http://www.51voa.com";
	static String URL_PAGE = "http://www.51voa.com/VOA_Standard_1.html";
	static String temp;
	static List<String> links = new ArrayList<String>();
	static String REGEX = "/VOA_Standard_English/.*?html";
	static String REGEX_MP3 = "/path.asp.*?mp3";

}
