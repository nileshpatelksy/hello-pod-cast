package com.meadsoft.bean;

public class MeadBean extends BaseBean{
	private String firstName = "Mead";
	private String lastName = "Lai";
	private int age = 10;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isAlive() {
		return true;
	}

}
