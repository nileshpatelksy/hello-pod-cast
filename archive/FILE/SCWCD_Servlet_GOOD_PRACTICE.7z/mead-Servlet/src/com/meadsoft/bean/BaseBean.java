/**
 * 
 */
package com.meadsoft.bean;

/**
 * @author Administrator
 *
 */
public abstract class BaseBean {

}
