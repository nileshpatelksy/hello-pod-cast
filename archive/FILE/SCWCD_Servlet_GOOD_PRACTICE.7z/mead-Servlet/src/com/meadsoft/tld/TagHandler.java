/**
 * 
 */
package com.meadsoft.tld;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.DynamicAttributes;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 * @author Administrator
 * 
 */
public class TagHandler extends SimpleTagSupport implements DynamicAttributes  {

	private String user;

	public void setUser(String user) {
		this.user = user;
	}

	public void doTag() throws IOException, JspException {
		JspWriter out = this.getJspContext().getOut();
		/**
		 * Here is getJspContext
		 */
		this.getJspContext();
		out.println("<span style='color:red'>$TagHandler$-Hello</span><h1 style='color: blue'>"
						+ this.user + "</h1>");
		this.getJspContext().setAttribute("msg",
				"<span style='color: pink'>Mesage From !</span>$TagHandler$");
		//Why do this?
		this.getJspBody().invoke(null);
		super.findAncestorWithClass(new SimpleTag(), TagHandler.class);
	}

	@Override
	public void setDynamicAttribute(String arg0, String arg1, Object arg2)
			throws JspException {
		// TODO Auto-generated method stub
		
	}

}
