package com.meadsoft.tld;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.SkipPageException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class SimpleTag extends SimpleTagSupport {

	private ArrayList<String> movies = new ArrayList<String>();
	private boolean mark = true;

	public void setMovies(ArrayList<String> movies) {
		this.movies = movies;
	}

	public void doTag() throws IOException, JspException {
		for (String i : movies) {
			if (i.equalsIgnoreCase("lai")) {
				throw new SkipPageException();
			}
			this.getJspContext().setAttribute("movie", i);
			this.getJspBody().invoke(null);
			this.getJspBody().getJspContext().getELContext();
		}
		JspWriter out = this.getJspContext().getOut();
		out.println("<br/>before**");
		if (mark) {
			throw new SkipPageException();
		}
		out.println("<br/>after**");
		
		String s = PageContext.SESSION;
		this.getJspContext().getOut();//�ǳ���Ҫ.
		/**
		 * no attribute, no invoke BODY content? Why?
		 */
		//this.getJspBody().invoke(null);
	}
}
