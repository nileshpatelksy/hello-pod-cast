/**
 * 
 */
package com.meadsoft.tld;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author Administrator
 *
 */
public class DiceRoller {

	public static List rollDice(String i){
		List<String> list = new ArrayList<String>();
		list.add("list"+i);
		list.add("list-a");
		list.add("list-b");
		return list;
	}
	public static HashMap mead(int i){
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("mead", "lai");
		map.put("test",""+i);
		return map;
	}
}
