/**
 * 
 */
package com.meadsoft.tld;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

/**
 * @author Administrator
 * 
 */
public class TranditionTag extends TagSupport {
	private static final long serialVersionUID = 1L;

	private JspWriter out;

	public int doStartTag() {
		//init it.
		out = this.pageContext.getOut();
		/**
		 * Here pageContext is a member,not method.
		 */
		Object obj = this.pageContext;
		//get parent...
		Tag parent = this.getParent();
		if (parent != null&& parent instanceof TranditionTag) {
			try {
				out.print(parent.getClass().getName());
				TranditionTag tag = (TranditionTag)parent;
				out.print(tag.mark);
				out.flush();
				out.print("<br/>");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		Tag find = TagSupport.findAncestorWithClass(this, TranditionTag.class);
		if(find!=null){
			try {
				out.println("<p style=\"color: blue\">Find findAncestorWithClass</p>");
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}		
		this.pageContext.setAttribute("", "");//�ǳ���Ҫ.
		return TagSupport.EVAL_BODY_INCLUDE;
		// return TagSupport.SKIP_BODY;//not invoke body
	}

	/**
	 * VAR is not thread safe. There is only one OBJ create, and provide to
	 * multi-Threads. so, the mark will increase all the time.
	 */
	private int mark = 0;

	public int getMark() {
		return mark;
	}

	public int doAfterBody() {
		if (mark == 0) {
			return TagSupport.SKIP_BODY;
		}
		// omit the following....
		if (mark++ < 2) {
			try {
				out.println("1#*" + mark);
			} catch (Exception e) {
			}
			return TagSupport.EVAL_BODY_AGAIN;
		} else {
			try {
				out.println("2#*" + mark);
			} catch (Exception e) {
			}
			// because the member VAR is not thread safe.
			// so need reset to 0;
			mark = 0;
			return TagSupport.SKIP_BODY;
		}
	}

	public int doEndTag() {
		try {
			out.println("in doEndTag");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return TagSupport.EVAL_PAGE;
	}
}
