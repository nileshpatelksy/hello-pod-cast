package com.meadsoft.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

/**
 * Application Lifecycle Listener implementation class SessionBindListener
 *
 */
public class SessionBindListener implements HttpSessionBindingListener {

    /**
     * Default constructor. 
     */
    public SessionBindListener() {
    	System.out.println("SessionBindListener");
    }

	/**
     * @see HttpSessionBindingListener#valueUnbound(HttpSessionBindingEvent)
     */
    public void valueUnbound(HttpSessionBindingEvent event) {
    	System.out.println("valueUnbound#####SessionBindListener##########3"+event.getName());
    	event.getSession();
    	
    }

	/**
     * @see HttpSessionBindingListener#valueBound(HttpSessionBindingEvent)
     */
    public void valueBound(HttpSessionBindingEvent event) {
    	System.out.println("valueBound#####"+event.getName());
//    	HttpSession session = event.getSession();
//    	System.out.println("valueBound#####"+session.getAttribute("count"));
    }
	
}
