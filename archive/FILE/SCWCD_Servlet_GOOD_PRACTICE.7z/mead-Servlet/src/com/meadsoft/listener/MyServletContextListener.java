package com.meadsoft.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.meadsoft.pojo.Dog;

/**
 * Application Lifecycle Listener implementation class MyServletContextListener
 *
 */
public class MyServletContextListener implements ServletContextListener {

  
    public MyServletContextListener() {       
    	System.out.println("MyServletContextListener");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent event) {
      	ServletContext sc = event.getServletContext();
      	String dogBreed = sc.getInitParameter("breed");
      	Dog dog = new Dog(dogBreed);
      	sc.setAttribute("dog", dog);
      	System.out.println("contextInitialized");
      	
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0) {
    	System.out.println("contextDestroyed");
    }
	
}
