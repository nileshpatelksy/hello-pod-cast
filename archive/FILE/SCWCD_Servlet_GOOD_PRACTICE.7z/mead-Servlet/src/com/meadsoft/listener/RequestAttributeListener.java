package com.meadsoft.listener;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;

/**
 * Application Lifecycle Listener implementation class RequestAttributeListener
 * 
 */
public class RequestAttributeListener implements
		ServletRequestAttributeListener {

	/**
	 * Default constructor.
	 */
	public RequestAttributeListener() {
		System.out.println("RequestAttributeListener");
	}

	/**
	 * @see ServletRequestAttributeListener#attributeAdded(ServletRequestAttributeEvent)
	 */
	public void attributeAdded(ServletRequestAttributeEvent event) {
		System.out.println("$RequestAttributeListener*attributeAdded:"
				+ event.getName() + "=" + event.getValue());
	}

	/**
	 * @see ServletRequestAttributeListener#attributeRemoved(ServletRequestAttributeEvent)
	 */
	public void attributeRemoved(ServletRequestAttributeEvent event) {
		System.out.println("$RequestAttributeListener*attributeRemoved:"
				+ event.getName() + "=" + event.getValue());
	}

	/**
	 * @see ServletRequestAttributeListener#attributeReplaced(ServletRequestAttributeEvent)
	 */
	public void attributeReplaced(ServletRequestAttributeEvent event) {
		//�����ȡ���Ǿɵ�ֵ
		System.out.println("$RequestAttributeListener*attributeReplaced:"
				+ event.getName() + "=" + event.getValue()+"=="+event.getSource());
	}

}
