package com.meadsoft.listener;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;

import org.w3c.dom.events.Event;

/**
 * Application Lifecycle Listener implementation class RequestListener
 *
 */
public class RequestListener implements ServletRequestListener {

    /**
     * Default constructor. 
     */
    public RequestListener() {
    	System.out.println("$RequestListener");
    }

	/**
     * @see ServletRequestListener#requestDestroyed(ServletRequestEvent)
     */
    public void requestDestroyed(ServletRequestEvent event) {
    	System.out.println("$RequestListener*requestDestroyed:RRRRR:"+event.getSource());
    }

	/**
     * @see ServletRequestListener#requestInitialized(ServletRequestEvent)
     */
    public void requestInitialized(ServletRequestEvent event) {
    	System.out.println("$RequestListener*requestInitialized:RRRRR:"+event.getServletRequest().isSecure());
    }
	
}
