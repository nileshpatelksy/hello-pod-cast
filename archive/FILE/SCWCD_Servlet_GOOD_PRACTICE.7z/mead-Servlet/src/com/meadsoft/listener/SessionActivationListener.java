package com.meadsoft.listener;

import javax.servlet.http.HttpSessionActivationListener;
import javax.servlet.http.HttpSessionEvent;

/**
 * Application Lifecycle Listener implementation class SessionActivationListener
 *
 */
public final class SessionActivationListener implements HttpSessionActivationListener {

    /**
     * Default constructor. 
     */
    public SessionActivationListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionActivationListener#sessionDidActivate(HttpSessionEvent)
     */
    public void sessionDidActivate(HttpSessionEvent event) {
        event.getSession();
    }

	/**
     * @see HttpSessionActivationListener#sessionWillPassivate(HttpSessionEvent)
     */
    public void sessionWillPassivate(HttpSessionEvent event) {
        // TODO Auto-generated method stub
    }
	
}
