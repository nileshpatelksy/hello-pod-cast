package com.meadsoft.listener;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;

/**
 * Application Lifecycle Listener implementation class
 * ServletContextAttributeListener
 * 
 */
public class MyServletContextAttributeListener implements
		javax.servlet.ServletContextAttributeListener {

	/**
	 * Default constructor.
	 */
	public MyServletContextAttributeListener() {
		System.out.println("MyServletContextAttributeListener");
	}

	/**
	 * @see MyServletContextAttributeListener#attributeAdded(ServletContextAttributeEvent)
	 */
	public void attributeAdded(ServletContextAttributeEvent event) {
		System.out.println("$ContextATTRIbuteAdded" + event.getName() + "##"
				+ event.getValue());
	}

	/**
	 * @see MyServletContextAttributeListener#attributeReplaced(ServletContextAttributeEvent)
	 */
	public void attributeReplaced(ServletContextAttributeEvent event) {
		System.out.println("$ContextATTRIbuteReplaced" + event.getName() + "##"
				+ event.getValue());
	}

	/**
	 * @see MyServletContextAttributeListener#attributeRemoved(ServletContextAttributeEvent)
	 */
	public void attributeRemoved(ServletContextAttributeEvent event) {
		System.out.println("$ContextATTRIbuteRemoved" + event.getName() + "##"
				+ event.getValue());
	}

}
