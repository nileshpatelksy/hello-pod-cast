package com.meadsoft.listener;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

/**
 * Application Lifecycle Listener implementation class SessionAttributeListener
 * 
 */
public class SessionAttributeListener implements HttpSessionAttributeListener {

	/**
	 * Default constructor.
	 */
	public SessionAttributeListener() {
		System.out.println("$SessionAttributeListener");
	}

	/**
	 * @see HttpSessionAttributeListener#attributeRemoved(HttpSessionBindingEvent)
	 */
	public void attributeRemoved(HttpSessionBindingEvent event) {
		System.out.println("$SessionattributeRemoved:" + event.getName());
		event.getSession();
	}

	/**
	 * @see HttpSessionAttributeListener#attributeAdded(HttpSessionBindingEvent)
	 */
	public void attributeAdded(HttpSessionBindingEvent event) {
		System.out.println("$SessionattributeAdded:" + event.getName());
	}

	/**
	 * @see HttpSessionAttributeListener#attributeReplaced(HttpSessionBindingEvent)
	 */
	public void attributeReplaced(HttpSessionBindingEvent event) {
		System.out.println("$attributeReplaced:" + event.getName()+"="+event.getValue());
	}

}
