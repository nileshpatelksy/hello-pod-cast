/**
 * 
 */
package com.meadsoft.service;

/**
 * @author Administrator
 *
 */
public class ColorService {

	/**
	 * 
	 */
	public ColorService() {
		
	}
	
	public String suggestProduct(String color){
		if(color.equalsIgnoreCase("amber")){
			return "<span style=\"color:red\">Sorry, out of sell!</span>";
		}
		return "<span style=\"color:blue\">Here is your beer, Enjoy it!</span>";
	}

}
