package com.meadsoft.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * main for beer app
 * @author Administrator
 *
 */
public class Mark extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Mark() {
		super();
	}
	public void init(){ 
		try {
			this.init(this.getServletConfig());
		} catch (ServletException e) {
		}
		this.getInitParameter("");
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		this.getInitParameter("");
		this.getInitParameterNames();
		this.getServletConfig();
		this.getServletContext();
		this.getServletName();
		request.getServerPort();
		request.getCharacterEncoding();
		request.getAuthType();
		request.getContextPath();
		request.getPathInfo();		
		request.getServletPath();
		request.getRequestURI();
		//request.getRequestDispatcher("test")
		
		response.addDateHeader("",12);//double not long
		response.isCommitted();//???	
		response.setCharacterEncoding("");
		response.encodeRedirectURL("");//only HTTP response has
		//response.sets
		//all the methods list wanna remember.
		
		HttpSession session =  request.getSession();
		session.getMaxInactiveInterval();
		session.getLastAccessedTime();//Time()΢����Ϊ��λ
		session.getServletContext();
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		this.doGet(request, response);
		//request.getr
	}

}