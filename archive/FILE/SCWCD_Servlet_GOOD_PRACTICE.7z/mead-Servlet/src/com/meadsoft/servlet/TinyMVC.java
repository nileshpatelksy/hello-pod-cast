package com.meadsoft.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.meadsoft.listener.SessionBindListener;
import com.meadsoft.pojo.Dog;
import com.meadsoft.service.ColorService;

/**
 * main for beer app
 * 
 * @author Administrator
 * 
 */
public class TinyMVC extends HttpServlet {
	private int count = 0;
	private static final long serialVersionUID = 1L;

	public TinyMVC() {
		super();
	}

	public void init() {
		this.getInitParameter("default_color");
		this.log("ddd");
		System.out.println("Servlet inited@@@@@@@@2--------"+this.getInitParameter("default_color"));
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		/**
		 * SERVLET initParameter
		 */
		String def_color = this.getInitParameter("default_color");

		def_color = this.getServletConfig().getInitParameter("default_color");

		/**
		 * ServletContext
		 */
		String context = this.getServletContext().getInitParameter("mead");
		ServletContext sc = this.getServletContext();
		Dog dog = (Dog) sc.getAttribute("dog");
		sc.setAttribute("mead", "mead lai-context");
		/**
		 * Session Practice
		 */
		String sessionString = "";
		HttpSession session = request.getSession(false);

		if (session == null) {
			session = request.getSession();
			sessionString += "NullSession#" + session.getId();
		} else {
			sessionString += "OKaySession#" + session.getId();
		}
		if (session.isNew()) {
			sessionString += "NewSession#";
		} else {
			sessionString += "OldSession#";
		}
		session.setAttribute("MeadLai", "mead");
		session.setAttribute("MeadLai", "lai");
		session.setAttribute("MeadLai", "princess");
		// remove a session not exist is allowed. no error
		session.removeAttribute("count");
		session.setAttribute("count", "#count=" + ++count);
		// cancel a session, than visit it will occur a error
		// session.invalidate();
		// response.
		session.setAttribute("BindingListener###", new SessionBindListener());

		/**
		 * Cookies Practice
		 */
		Cookie cookie = new Cookie("mead", "0");
		response.addCookie(cookie);

		// output...
		PrintWriter out = response.getWriter();
		out
				.println("init: ## " + def_color + "  <br/>context## "
						+ context + "  <br/>dog## " + dog.getBreed()
						+ "  <br/>session## " + sessionString + "##"
						+ (String) session.getAttribute("count"));
		String select_color = request.getParameter("color");
		if (select_color == null) {
			select_color = "";
		}
		ColorService cs = new ColorService();
		String result = cs.suggestProduct(select_color);
		out.println("<br/>" + result);
		out.println("<br/>Thanks!");
		/**
		 * flush will cause a tomcat inner Exception. but not the browser, It
		 * will show a nice page...
		 **/
		// response.flushBuffer();
		request.setAttribute("result", "well");
		request.setAttribute("result", "okay");
		request.setAttribute("result", result);
		RequestDispatcher view = request
				.getRequestDispatcher("/beer/result.jsp");
		// sc.removeAttribute("mead");//jsp wanna this value,if del here, ERROR
		//view.forward(request, response);
		/**
		 * view.forward and sendRedirect is not allow use together. It must to
		 * occur exception and show a Error page.
		 **/
		// response.sendRedirect("beer/result.jsp");
		/**
		 * well, Its legal to remove ContextAttribute here.
		 */
		sc.removeAttribute("mead");
		session.invalidate();
		out.print("<br>");
		out.println("PathInfo=" + request.getPathInfo());
		out.print("<br>");
		out.println("getRequestURI()=" + request.getRequestURI());
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		this.doGet(request, response);
		// request.getr
	}

}