/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.JMSException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyContent;

/** Defines a property on an outer JMS Message
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public class PropertyTag extends AbstractBodyTag {

    /** Stores the name of the property */
    private String name;
    
    /** Stores the value of the property */
    private Object value;
    
    
    // BodyTag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        if ( value != null ) {
            fireSetProperty();
            return SKIP_BODY;
        }
        return EVAL_BODY_TAG;
    }
    
    public int doAfterBody() throws JspException {
        BodyContent body = getBodyContent();
        value = body.getString();
        body.clearBody();
        fireSetProperty();
        return EVAL_PAGE;
    }
    
    public void release() {
        name = null;
        value = null;
    }
    
    // Properties
    //-------------------------------------------------------------------------                    
    /** Sets the name of the JMS property
      */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Sets the value of the JMS property. 
      * If no value is set then the body of the tag is used
      */
    public void setValue(Object value) {
        this.value = value;
    }
    
    // Implementation methods
    //-------------------------------------------------------------------------                        
    protected void fireSetProperty() throws JspException {
        try {
            MessageTag tag = (MessageTag) findAncestorWithClass( this, MessageTag.class );
            if ( tag == null ) {
                throw new JspException("<jms:property> tag must be within a <jms:message> tag");
            }
            tag.addProperty( name, value );
        }
        catch (JMSException e) {
            throw new JspException( "Failed to set Message header property name: " + name + " value: " + value + ". Reason: " + e, e );
        }
    }    
}
