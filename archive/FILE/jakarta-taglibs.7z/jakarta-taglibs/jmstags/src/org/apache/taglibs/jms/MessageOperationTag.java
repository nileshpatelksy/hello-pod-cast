/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.servlet.jsp.JspException;

import org.apache.commons.messenger.Messenger;

/** An abstract base class for JMS Message operation tags such as send, receive or call.
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public abstract class MessageOperationTag extends AbstractTag implements ConnectionContext {

    /** The Messenger used to access the JMS connection */
    private Messenger connection;
    
    /** The Destination */
    private Destination destination;
    
    public MessageOperationTag() {
    }
    
    // Tag interface
    //-------------------------------------------------------------------------                    
    public void release() {
        super.release();
        connection = null;
        destination = null;
    }
    
    
    // Properties
    //-------------------------------------------------------------------------                                
    public Messenger getConnection() throws JspException, JMSException {
        if ( connection == null ) {
            return findConnection();
        }
        return connection;
    }
    
    public void setConnection(Messenger connection) {
        this.connection = connection;
    }
    
    public Destination getDestination() {
        return destination;
    }
    
    public void setDestination(Destination destination) {
        this.destination = destination;
    }

    // Implementation methods
    //-------------------------------------------------------------------------                            
    protected Messenger findConnection() throws JspException, JMSException {
        ConnectionContext messengerTag = (ConnectionContext) findAncestorWithClass( this, ConnectionContext.class );
        if ( messengerTag == null ) {
            throw new JspException("This tag must be within a <jms:connection> tag or the 'connection' attribute should be specified");
        }
        return messengerTag.getConnection();
    }
}    
