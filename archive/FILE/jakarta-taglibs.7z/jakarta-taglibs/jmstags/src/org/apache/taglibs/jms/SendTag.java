/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.jms;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.servlet.jsp.JspException;

/** Sends a JMS message to some destination.
  *
  * @author <a href="mailto:jstrachan@apache.org">James Strachan</a>
  * @version $Revision: 216790 $
  */
public class SendTag extends MessageOperationTag {

    /** The JMS Message to be sent */
    private Message message;
    
    public SendTag() {
    }
        
    // TagTag interface
    //-------------------------------------------------------------------------                    
    public int doStartTag() throws JspException {
        return EVAL_BODY_INCLUDE;
    }
    
    public int doEndTag() throws JspException {
        try {
            Message message = getMessage();
            if ( message == null ) {
                throw new JspException( "No message specified. Either specify a 'message' attribute or use a nested <jms:message> tag" );
            }
            Destination destination = getDestination();
            if ( destination == null ) {
                throw new JspException( "No destination specified. Either specify a 'destination' attribute or use a nested <jms:destination> tag" );
            }
            getConnection().send( destination, message );
        }
        catch (JMSException e) {
            throw new JspException( "Failed to send JMS message: " + e, e );
        }
        return EVAL_PAGE;
    }
    
    public void release() {
        super.release();
        message = null;
    }
    
    
    // Properties
    //-------------------------------------------------------------------------                            
    public Message getMessage() {
        return message;
    }
    
    public void setMessage(Message message) {
        this.message = message;
    }
}    
