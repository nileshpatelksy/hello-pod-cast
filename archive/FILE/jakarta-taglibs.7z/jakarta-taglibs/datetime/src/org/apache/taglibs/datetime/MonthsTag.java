/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.datetime;

import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>months</b>, used to loop through all the months of the year
 * so that month names can be accessed by using the standard
 * JSP &lt;jsp:getProperty&gt; tag.
 * <p>
 * The script variable of name <b>id</b> is availble only within the
 * body of the <b>months</b> tag.
 * <p>
 * Loops through all the months.
 * <p>
 * If the optional attribute <b>locale</b> is true, the month names
 * are formatted for the clients locale if known.
 * <p>
 * The optional attribute <b>localeRef</b> can be used to specify
 * the name of a page, session, application, or request scope attribute
 * of type java.util.Locale to use.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;months&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.datetime.MonthsTag&lt;/tagclass&gt;
 * &lt;teiclass&gt;org.apache.taglibs.datetime.MonthsTEI&lt;/teiclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Loop through all the months of the year.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;locale&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;                             
 *     &lt;name&gt;localeRef&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @author Glenn Nielsen
 */

public class MonthsTag extends BodyTagSupport
{
    // Static constants                     
    private static String PATTERN = "yyyy";

    // months tag attributes
    private boolean locale_flag = false;
    private String localeRef = null;

    // months tag invocation variables
    private String [] short_months = null;
    private String [] long_months = null;
    private int month = 0;
    private int month_num = 1;

    /**
     * Initializes tag so it can loop through the months of the year.
     *
     * @return EVAL_BODY_TAG
     */
    public final int doStartTag() throws JspException
    {
        // Initialize variables
        month = 0;
        month_num = 1;

        SimpleDateFormat sdf;
        // Get a SimpleDateFormat using locale if necessary
        if( localeRef != null ) {
            Locale locale = (Locale)pageContext.findAttribute(localeRef);
            if( locale == null ) {
                throw new JspException(
                    "datetime amPms tag could not find locale for localeRef \"" +
                    localeRef + "\".");
            }
 
            sdf = new SimpleDateFormat(PATTERN,locale);
        } else if( locale_flag ) {
            sdf = new SimpleDateFormat(PATTERN,
                      (Locale)pageContext.getRequest().getLocale());
        } else {
            sdf = new SimpleDateFormat(PATTERN);
        }

	DateFormatSymbols dfs = sdf.getDateFormatSymbols();
	short_months = dfs.getShortMonths();
	long_months = dfs.getMonths();
	// Make sure we skip any blank array elements
        while( month < long_months.length && 
            (long_months[month] == null || long_months[month].length() == 0) )
                month++;
        if( month >= short_months.length )
            return SKIP_BODY;

	pageContext.setAttribute(id,this,PageContext.PAGE_SCOPE);
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of each months tag.
     *
     * @return EVAL_BODY_TAG if there is another month, or SKIP_BODY if there are no more months
     */
    public final int doAfterBody() throws JspException
    {
	// See if we are done looping through months
	month++;
	month_num++;
        if( month >= short_months.length )
            return SKIP_BODY;
	// Make sure we skip any blank array elements
        while( month < long_months.length && 
	    (long_months[month] == null || long_months[month].length() == 0) )
                month++;

	if( month >= short_months.length )
	    return SKIP_BODY;

	// There is another month, so loop again
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of Tag
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
        pageContext.removeAttribute(id,PageContext.PAGE_SCOPE);
	try
	{
	    if(bodyContent != null)
	    bodyContent.writeOut(bodyContent.getEnclosingWriter());
	} catch(java.io.IOException e)
	{
	    throw new JspException("IO Error: " + e.getMessage());
	}
	return EVAL_PAGE;
    }

    /**
     * Locale flag, if set to true, use month names
     * for client's preferred locale if known.
     *
     * @param boolean either <b>true</b> or <b>false</b>
     */
    public final void setLocale(boolean flag)
    {
        locale_flag = flag;
    }

    /**
     * Returns the short name of the month.
     * <p>
     * &lt;jsp:getProperty name=<i>"id"</i> property="shortMonth"/&gt;
     *
     * @return String - short name of the month
     */
    public final String getShortMonth()
    {
	return short_months[month];
    }

    /**
     * Returns the long name of the month.
     * <p>
     * &lt;jsp:getProperty name=<i>"id"</i> property="month"/&gt;
     *
     * @return String - long name of the month
     */
    public final String getMonth()
    {  
        return long_months[month];
    }

    /**
     * Provides a key to search the page context for in order to get the
     * java.util.Locale to use.
     *
     * @param String name of locale attribute to use
     */
    public void setLocaleRef(String value)
    {
        localeRef = value;
    }

    /**
     * Returns the number of the month.
     * <p>         
     * &lt;jsp:getProperty name=<i>"id"</i> property="monthOfYear"/&gt;
     *             
     * @return String - number of the month
     */            
    public final String getMonthOfYear()
    {              
	if( month_num < 10 )
	    return "0" + month_num;
        return "" + month_num;
    }

}
