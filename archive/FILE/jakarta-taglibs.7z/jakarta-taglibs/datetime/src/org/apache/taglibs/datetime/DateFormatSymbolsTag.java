/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.datetime;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.MissingResourceException;
import java.text.DateFormatSymbols;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.JspException;

/**
 * <p>
 * This class implements an empty tag that allows you to use a custom symbols
 * for date formating.</p>
 * <p>
 * Must be specified attribute baseName that point to property file.
 * </p>
 * <p>
 * Property file contains key\value pair in such rule<br>
 * # Month symbols change on custom<br>
 * month=true<br>
 * month0=January<br>
 * month1=February<br>
 * # Era symbols change on custom<br>
 * era=true<br>
 * era0=before<br>
 * era1=after<br>
 *
 * </p>
 *
 * @author <a href="mailto:wigor@bigmir.net">Kozlov Igor</a>
 */
public class DateFormatSymbolsTag extends TagSupport {

    private int scope = PageContext.PAGE_SCOPE;
    private String localeRef = null;
    private boolean locale_flag = false;
    private String baseName = null;

    private ResourceBundle bundle;
    private DateFormatSymbols dateFormatSymbols;

    public void setScope(String scope) {
        if (scope.toLowerCase().equals("application")) {
            this.scope = PageContext.APPLICATION_SCOPE;
        } else if (scope.toLowerCase().equals("session")) {
            this.scope = PageContext.SESSION_SCOPE;
        } else if (scope.toLowerCase().equals("request")) {
            this.scope = PageContext.REQUEST_SCOPE;
        } else if (scope.toLowerCase().equals("page")) {
            this.scope = PageContext.PAGE_SCOPE;
        }
    }

    public void setBaseName(String baseName) {
        this.baseName = baseName;
    }

    public void setLocale(boolean locale) {
        this.locale_flag = locale;
    }

    public void setLocaleRef(String localeRef) {
        this.localeRef = localeRef;
    }

    public int doStartTag() throws JspException {
        Locale locale = null;
        if (localeRef != null) {
            locale = (Locale) pageContext.findAttribute(localeRef);
        } else if (locale_flag) {
            locale = pageContext.getRequest().getLocale();
        } else {
            dateFormatSymbols = new DateFormatSymbols();
        }
        findBundle(locale);
        buildDateFormatSymbols(locale);
        if (this.getId() != null) {
            pageContext.setAttribute(this.getId(), dateFormatSymbols, scope);
        }
        return SKIP_BODY;
    }

    public void release() {
        super.release();
        scope = PageContext.PAGE_SCOPE;
        localeRef = null;
        locale_flag = false;
        baseName = null;
    }

    private void buildDateFormatSymbols(Locale locale) {
        if (locale != null) {
            dateFormatSymbols = new DateFormatSymbols(locale);
        } else {
            dateFormatSymbols = new DateFormatSymbols();
        }
        // Set ampm string
        try {
            String customAmPm = bundle.getString("ampm");
            if ("true".equals(customAmPm)) {
                String ampm[] = new String[2];
                for (int i = 0; i < 2; i++) {
                    ampm[i] = bundle.getString("ampm" + i);
                }
                dateFormatSymbols.setAmPmStrings(ampm);
            }
        } catch (MissingResourceException e) {
        }

        // Set era strings
        try {
            String customEras = bundle.getString("eras");
            if ("true".equals(customEras)) {
                String eras[] = new String[2];
                for (int i = 0; i < 2; i++) {
                    eras[i] = bundle.getString("eras" + i);
                }
                dateFormatSymbols.setEras(eras);
            }
        } catch (MissingResourceException e) {
        }

        // Set short month strings
        try {
            String customShortMonth = bundle.getString("shortmonth");
            if ("true".equals(customShortMonth)) {
                String shortmonth[] = new String[12];
                for (int i = 0; i < 12; i++) {
                    shortmonth[i] = bundle.getString("shortmonth" + i);
                }
                dateFormatSymbols.setShortMonths(shortmonth);
            }
        } catch (MissingResourceException e) {
        }

        // Set month strings
        try {
            String customMonth = bundle.getString("month");
            if ("true".equals(customMonth)) {
                String month[] = new String[12];
                for (int i = 0; i < 12; i++) {
                    month[i] = bundle.getString("month" + i);
                }
                dateFormatSymbols.setMonths(month);
            }
        } catch (MissingResourceException e) {
        }

        // Set weekdays strings
        try {
            String customWeekdays = bundle.getString("weekdays");
            if ("true".equals(customWeekdays)) {
                String weekdays[] = new String[7];
                for (int i = 0; i < 7; i++) {
                    weekdays[i] = bundle.getString("weekdays" + i);
                }
                dateFormatSymbols.setWeekdays(weekdays);
            }
        } catch (MissingResourceException e) {
        }

        // Set short weekdays strings
        try {
            String customShortWeekdays = bundle.getString("shortweekdays");
            if ("true".equals(customShortWeekdays)) {
                String shortweekdays[] = new String[7];
                for (int i = 0; i < 7; i++) {
                    shortweekdays[i] = bundle.getString("shortweekdays" + i);
                }
                dateFormatSymbols.setShortWeekdays(shortweekdays);
            }
        } catch (MissingResourceException e) {
        }
    }

    private void findBundle(Locale locale) {
        if (locale != null) {
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            bundle = ResourceBundle.getBundle(baseName, locale, cl);
        } else {
            bundle = ResourceBundle.getBundle(baseName);
        }
    }

}
