/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.datetime;

import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>eras</b>, used to loop through all the era strings
 * so that they can be accessed by using the standard
 * JSP &lt;jsp:getProperty&gt; tag.
 * <p>
 * The script variable of name <b>id</b> is availble only within the
 * body of the <b>eras</b> tag.
 * <p>
 * Loops through all the era strings.
 * <p>
 * If the optional attribute <b>locale</b> is true, the strings
 * are formatted for the clients locale if known.
 * <p>                                                         
 * The optional attribute <b>localeRef</b> can be used to specify
 * the name of a page, session, application, or request scope attribute
 * of type java.util.Locale to use.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;eras&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.datetime.ErasTag&lt;/tagclass&gt;
 * &lt;teiclass&gt;org.apache.taglibs.datetime.ErasTEI&lt;/teiclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Loop through all the era names.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;locale&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;                             
 *     &lt;name&gt;localeRef&lt;/name&gt;
 *     &lt;required&gt;false&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @author Glenn Nielsen
 */

public class ErasTag extends BodyTagSupport
{
    // Static constants                     
    private static String PATTERN = "yyyy";

    // eras tag attributes
    private boolean locale_flag = false;
    private String localeRef = null;

    // eras tag invocation variables
    private String [] eras = null;
    private int count = 0;

    /**
     * Initializes tag so it can loop through the eras of the year.
     *
     * @return EVAL_BODY_TAG
     */
    public final int doStartTag() throws JspException
    {
        // Initialize variables                      
        count = 0;

        SimpleDateFormat sdf;
        // Get a SimpleDateFormat using locale if necessary
        if( localeRef != null ) {                          
            Locale locale = (Locale)pageContext.findAttribute(localeRef);
            if( locale == null ) {                                       
                throw new JspException(                                  
                    "datetime eras tag could not find locale for localeRef \"" +
                    localeRef + "\".");                                          
            }                                                                    
 
            sdf = new SimpleDateFormat(PATTERN,locale);
        } else if( locale_flag ) {
            sdf = new SimpleDateFormat(PATTERN,
                      (Locale)pageContext.getRequest().getLocale());
        } else {
            sdf = new SimpleDateFormat(PATTERN);
        }

	DateFormatSymbols dfs = sdf.getDateFormatSymbols();
	eras = dfs.getEras();
	// Make sure we skip any blank array elements
        while( count < eras.length && 
            (eras[count] == null || eras[count].length() == 0) )
                count++;
        if( count >= eras.length )
            return SKIP_BODY;

        pageContext.setAttribute(id,this,PageContext.PAGE_SCOPE);
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of each eras tag.
     *
     * @return EVAL_BODY_TAG if there is another era, or SKIP_BODY if there are no more eras
     */
    public final int doAfterBody() throws JspException
    {
	// See if we are done looping through eras
	count++;
        if( count >= eras.length )
            return SKIP_BODY;
	// Make sure we skip any blank array elements
        while( count < eras.length && 
	    (eras[count] == null || eras[count].length() == 0) )
                count++;

	if( count >= eras.length )
	    return SKIP_BODY;

	// There is another era, so loop again
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of Tag
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
        pageContext.removeAttribute(id,PageContext.PAGE_SCOPE);
	try
	{
	    if(bodyContent != null)
	    bodyContent.writeOut(bodyContent.getEnclosingWriter());
	} catch(java.io.IOException e)
	{
	    throw new JspException("IO Error: " + e.getMessage());
	}
	return EVAL_PAGE;
    }

    /**
     * Locale flag, if set to true, use era names
     * for client's preferred locale if known.
     *
     * @param boolean either <b>true</b> or <b>false</b>
     */
    public final void setLocale(boolean flag)
    {
        locale_flag = flag;
    }

    /**
     * Provides a key to search the page context for in order to get the
     * java.util.Locale to use.
     *  
     * @param String name of locale attribute to use 
     */
    public void setLocaleRef(String value)
    {
        localeRef = value;
    }

    /**
     * Returns the era name.
     * <p>
     * &lt;jsp:getProperty name=<i>"id"</i> property="name"/&gt;
     *
     * @return String - era name
     */
    public final String getName()
    {  
        return eras[count];
    }

}
