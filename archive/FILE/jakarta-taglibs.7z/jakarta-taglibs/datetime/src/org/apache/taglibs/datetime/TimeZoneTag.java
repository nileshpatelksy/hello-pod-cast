/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.datetime;

import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>timeZone</b>, used to set the client timeZone for
 * the SESSION as a script variable.
 * <p>
 * The TimeZone ID String is obtained from the body of the tag.
 * If there is no TimeZone ID String, the server default timeZone is used.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;timeZone&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.datetime.TimeZoneTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Creates a SESSION script variable for clients time zone.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;id&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @author Glenn Nielsen
 */

public class TimeZoneTag extends BodyTagSupport
{

    /**
     * Method called at start of tag, always returns EVAL_BODY_TAG
     *
     * @return EVAL_BODY_TAG
     */
    public final int doStartTag() throws JspException
    {
	return EVAL_BODY_TAG;
    }

    /**
     * Method called at end of timeZone tag body.
     *
     * @return SKIP_BODY
     */
    public final int doAfterBody() throws JspException
    {
	// Use the body of the tag as input for the timeZone
	BodyContent body = getBodyContent();
	String s = body.getString().trim();  
	// Clear the body since we only use it to set the timeZone
	body.clearBody();

	TimeZone tz = TimeZone.getTimeZone(s);
	if( tz == null )
	    tz = TimeZone.getDefault();

	pageContext.setAttribute(id,tz,PageContext.SESSION_SCOPE);
	return SKIP_BODY;
    }

    /**
     * Method called at end of Tag
     *
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
	return EVAL_PAGE;
    }

}
