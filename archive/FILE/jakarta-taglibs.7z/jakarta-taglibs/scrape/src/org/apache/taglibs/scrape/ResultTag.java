/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * ResultTag - JSP tag <b>result</b> returns the result of the scrape uniquely
 *             identified by a scrapeid.
 *
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;result&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.scrape.ResultTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;empty&lt;/bodycontent&gt;
 * &lt;info&gt;Get the HTML extracted by the scrape of a page&lt;/info&gt;
 *
 * &lt;attribute&gt;
 *	  &lt;name&gt;scrape&lt;/name&gt;
 *	  &lt;required&gt;true&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * </pre></p></p>
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 * @see PageData
 *
 */
public class ResultTag extends TagSupport {

    // the unique id for this scrape
  private String scrape;

    /**
     *  implementation of method from the Tag interface that tells the JSP
     *  what to do upon encountering the end tag for this tag
     *
     *  @throws JSPException  thrown when error occurs in processing the body
     *                        of this method
     *
     *  @return EVAL_PAGE  int telling the tag handler that the rest of the jsp
     *                     page is to be evaluated
     */
  public final int doEndTag() throws JspException {

      String result; // holds the result for the scrape named by scrape

      // get the result attribute from pagescope matched to scrape
      if((result = (String)pageContext.getAttribute(scrape)) != null)
      {
          try {
	      pageContext.getOut().write(result); // write out result
          } catch(IOException e) {
            pageContext.getServletContext().log("Scrape taglib: Result tag: " +
                   e.toString() + " Couldn't perform the write");
          }
      } else {
	  // write out nothing if scrape id is not matched
	  try {
	      pageContext.getOut().write("");
	  } catch(IOException e) {
            pageContext.getServletContext().log("Scrape taglib: Result tag: " +
                   " Couldn't perform the write scrape does not exist.  " + 
                   e.toString());
          }
      }
      return EVAL_PAGE;
  } 

    /**
     * setter method for scrapeid
     *
     * @param scrapeid  the unique id for this scrape
     *
     */
  public final void setScrape(String scrapeid) {
      scrape = scrapeid;
  }

}
