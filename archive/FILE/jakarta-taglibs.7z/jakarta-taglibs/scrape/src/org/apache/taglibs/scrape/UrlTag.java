/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.util.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * UrlTag - JSP tag <b>url</b> is used for dynamically setting the url of the
 *          page that is going to be scraped by the tag library it is necessary
 *          the tag be nested within a <b>page</b> tag.
 *
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;url&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.scrape.UrlTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;
 *     Does the scraping of the page named in the parent page tag
 * &lt;/info&gt;
 * </pre></p></p>
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 * @see ScrapeData
 *
 */
public class UrlTag extends BodyTagSupport {


    /**
     *  implementation of the method from the tag interface that tells the JSP
     *  page what to do after the body of this tag
     *
     *  @throws JSPException  thrown when an error occurs while processing the
     *                        body of this method
     *
     *  @return SKIP_BODY  int telling the tag handler to not evaluate the body
     *                     of this tag again
     *
     */
    public final int doAfterBody() throws JspException {

	// parent tag must be a PageTag, gives access to methods in parent
	PageTag myparent = (PageTag)javax.servlet.jsp.tagext.TagSupport.findAncestorWithClass(this, PageTag.class);
        String url;  // the url for the page to be scraped

	if (myparent == null)
	    throw new JspException("url tag not nested within page tag");
        else {
	    if ((url = bodyContent.getString()) != null) {
		myparent.setUrl(url); // set the url in the parent tag
		myparent.getPage();   // get the pagedata object for this scrape
	    } else
		throw new JspException("Url for the page to be scraped was not "
				       + "provided");
	}
	return SKIP_BODY;
    }
}
