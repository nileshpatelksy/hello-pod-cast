/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.util.*;
import java.io.*;
import java.net.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import org.apache.taglibs.scrape.*;

/**
 * PageTag - JSP tag <b>page</b> is used for generating an http request to a web
 *           page, it then scrapes the page for user specified text and stores
 *           the results from the scrape for later retrieval by another tag.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre> 
 * &lt;name&gt;page&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.scrape.PageTag&lt/tagclass&gt;
 * &lt;bodycontent&gtJSP&lt;/bodycontent&gt;
 * &lt;info&gt;Set the page that will be scraped&lt;/info&gt;
 *
 * &lt;attribute&gt;
 *	  &gt;name&gt;url&lt;/name&gt;
 *	  &lt;required&gt;false&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtsprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *        &lt; name&gt;time&lt;/name&gt;
 *        &lt;required&gt;false&lt;/required&gt;
 *        &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &gt;name&gt;useProxy&lt;/name&gt;
 *	  &lt;required&gt;false&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtsprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &gt;name&gt;proxyPort&lt;/name&gt;
 *	  &lt;required&gt;false&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtsprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *        &lt; name&gt;proxyServer&lt;/name&gt;
 *        &lt;required&gt;false&lt;/required&gt;
 *        &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *	  &gt;name&gt;proxyName&lt;/name&gt;
 *	  &lt;required&gt;false&lt;/required&gt;
 *	  &lt;rtexprval&gt;false&lt;/rtsprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *        &lt; name&gt;proxyPass&lt;/name&gt;
 *        &lt;required&gt;false&lt;/required&gt;
 *        &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *        &lt; name&gt;proxyEncode&lt;/name&gt;
 *        &lt;required&gt;false&lt;/required&gt;
 *        &lt;rtexprval&gt;false&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * &lt;attribute&gt;
 *        &lt; name&gt;charset&lt;/name&gt;
 *        &lt;required&gt;false&lt;/required&gt;
 *        &lt;rtexprval&gt;true&lt;/rtexprval&gt;
 * &lt;/attribute&gt;
 * </pre></p></p>
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 * @see PageData
 * @see ScrapeData
 *
 */
public class PageTag extends TagSupport {

    // url for the web page the user wants to scrape it gets stored in a 
    // pagedata object
    private String url;
    //default time before http connection is created again
    private long time = 600000;
    // holds an instance of the application scope data object that stores the 
    // data on this scrape
    private PageData pagedata;
    // the port to use for the proxy connection
    private int pport = -1;
    // the proxy server to use for the connection
    private String pserver = null;
    // username for proxy server if it requires basic authentication
    private String pname = null;
    // password for proxy server if it requires basic authentication
    private String ppass = null;
    // boolean value determines if the connection to to travel via a secure 
    // connection
    private boolean ssl = false;
    // the password to the client keystore for client side ssl authentication
    private String sslpass = null;
    // charset of the page scrapped
    private String charset = null;


    /**
     * implementation of method from the tag interface that tells the JSP what
     * to do upon encounteringa the start tag for this tag
     *
     * @throws JspException  thrown when an error occurs with client request
     *                       processing
     *
     * @return integer value that tells the JSP engine to evaluate the body
     *         of this tag
     *
     */
    public final int doStartTag() throws JspException {
        // if attribute url was given get pagedata object keyed to url from
	// static hashmap
	if (url != null)
	    getPage();
	return EVAL_BODY_INCLUDE; // evaluate the body
    }

    /**
     * implementation of method from the Tag interface that tells the JSP what
     * to do upon encountering the end tag for this tag
     *
     * @throws JspException  thrown when error occurs in processing the body of
     *                       this method
     *
     * @return integer value telling the JSP engine to evaluate the rest of the
     *         jsp page
     *
     */
    public final int doEndTag() throws JspException {
        // attempt to scrape from the page named by url
	pagedata.scrapePage(url, time, pageContext, charset);
	// put scrape results in the pagescope for access by result tag
	putScrapes();
	return EVAL_PAGE;
    }

    /**
     * method gets the page object from the from the static hashmap keyed to the
     * url
     *
     */
    public final void getPage() {
      //pagedata = PageData.getPage(url, pport, pserver, ssl, pname, ppass);
	pagedata = PageData.getPage(url, pport, pserver, pname, ppass);
    }

    /**
     * sets the time user would like the tag to wait before making a new http
     * connection default is 10 minutes.  method is used by the JSP container
     * to set the time attribute given in the page tag
     *
     * @param string  time in minutes must be greater than 10
     *
     */
    public final void setTime(String wait) throws JspException {
	long temp; // temporary variable for converting value
	try {
	    Long num = new Long(wait);
	    temp = num.longValue();
	    if (temp > 10) {
		time = temp * 60000;
	    }
	} catch(NumberFormatException nfe) {
	    // throw a JspException so that jsp page author can see error
	    throw new JspException("Scrape: Page tag: the time attribute needs"
                                  + " to be an integer");
	}
    }

    /**
     * sets the url for the http request.  method is used by the JSP container
     * to set the time attribute given in the page tag
     *
     * @param url  the url for the http request
     *
     */
    public final void setUrl(String url) throws JspException {
	this.url = url.trim();
	if (url.startsWith("https"))
	    ssl = true;
    }

    /**
     * set the value of proxy port
     *
     * @param value  the proxy port to use for the connection as a String
     *
     */
    public final void setuseProxy(String value) throws JspException {
	if (value.equalsIgnoreCase("true")) {
	    pserver = System.getProperty("http.proxyHost");
	    pport = Integer.getInteger("http.proxyPort").intValue();
	}
    }

    /**
     * set the value of proxy port
     *
     * @param value  the proxy port to use for the connection as a String
     *
     */
    public final void setProxyPort(String value) throws JspException {
	try {
	    pport = new Integer(value).intValue();
	} catch(NumberFormatException nfe) {
	    // throw a JspException so that jsp page author can see error
	    throw new JspException("Scrape: Page tag: the proxyPort attribute needs"
                                  + " to be an integer");
	}
    }

    /**
     * set the value of proxy server
     *
     * @param value  the proxy server to use for the connection
     *
     */
    public final void setProxyServer(String value) {
	pserver = value;
    }

    /**
     * set the value of the password for authentication to the proxy server
     *
     * @param value  the proxy port to use for the connection as a String
     *
     */
    public final void setProxyPass(String value) {
	ppass = value;
    }

    /**
     * set the value of the username for authentication to the proxy server
     *
     * @param value  the proxy server to use for the connection
     *
     */
    public final void setProxyName(String value) {
	pname = value;
    }

    /**
     * set the pass word to access the client keystore
     *
     * @param value  password to the client keystore
     *
     */
    public final void setClientPass(String value) {
	sslpass = value;
    }

    /**
     * set the name and value of any extra headers to be sent
     *
     * @param name   string that is the name of an extra header to be sent
     * @param value  string that is the value of an extra header to be sent
     */
    public final void setHeader(String name, String value) {
	pagedata.setHeader(name, value);
    }

    /**
     * set the value of the charset to be used 
     *
     * @param value charset to be used to scrape the page
     *
     */
    public final void setCharset(String value) {
	charset = value;
    }
    /**
     * method sets the scrapedata object in the hashmap scrapes in the
     * application scope pagedata object
     *
     * @param id  unique identifier of the scrape the following attributes
     *            define
     * @param begin  beginning anchor for the scrape refered to by id
     * @param end  ending anchor for the scrape refered to by id
     * @param anchors  boolean flag that determines if begin and end anchors are
     *                 part of the result
     * @param strip  boolean flag that determines if tags are to be striped from
     *               the result
     *
     */
    public final void setScrape(String id, String begin, String end, 
                             String anchors, String strip) throws JspException {

	// set the scrape in the hashmap scrapes in PageData
	pagedata.setScrape(id, begin, end, anchors, strip);
    }

    /**
     * method to trace through the hashmap of scrapes and place the result from
     * each scrape in the pagescope for access by the result tag
     *
     */
    private final void putScrapes() {
        // set of keys for the hashmap scrapes
        Set scrapedatakeys = pagedata.getKeySet();
        // iterators for scrapedatakeys two are needed one for getting
	// scrapedata object and one for setting result in pagescope
        Iterator scrapesit1 = scrapedatakeys.iterator();
        Iterator scrapesit2 = scrapedatakeys.iterator();

        // iterate through the scrapedata objects and perform a scrape for each
	// one
        while(scrapesit1.hasNext()) {

	    // get result from scrapedata object and place in pagescope
	    pageContext.setAttribute((String)scrapesit2.next(),
		pagedata.getScrape((String)scrapesit1.next()).getResult());
	}
    }
}
