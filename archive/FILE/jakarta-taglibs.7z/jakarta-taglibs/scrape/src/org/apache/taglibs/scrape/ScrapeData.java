/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.scrape;

import java.util.*;

/**
 * ScrapeData - An object used to store data for a scrape, data stored is a
 *                scrapeid, begin and end markers, flags, and the results of
 *                the scrape 
 *
 * @author Rich Catlett
 *
 * @version 1.0
 *
 */
public class ScrapeData {

    /**
     * flag determines if tags (anything enclosed by < >) are kept in the result
     */
    private boolean stripflag = false;
    /**
     * flag determines if begin and end markers are kept in the result default
     * value of false says they are not kept
     */
    private boolean anchorsflag = false;
    /**
     * beginning marker of this request
     */
    private String begin = new String();
    /**
     * end marker of this request
     */
    private String end = new String();
    /**
     * the result of this particular scrape
     */
    private StringBuffer result = new StringBuffer("");

    /**
     * constructor simply creates an instance of ScrapeData
     *
     */
    public ScrapeData() {}

    /**
     * getter method for stripflag
     *
     * @return boolean value of the Boolean object stripflag
     *
     */
    public final boolean getstripFlag() {
	return stripflag;
    }

    /**
     * setter method for stripflag
     *
     * @param notags  a boolean value that determines if tags are kept in the
     *                result
     */
    public final void setstripFlag(String notags) {
	if (notags.equalsIgnoreCase("true"))
	    stripflag = true;
	else 
	    stripflag = false;
    }

    /**
     * getter method for anchorsflag
     *
     * @return boolean value of anchorsflag
     *
     */
    public final boolean getanchorsFlag() {
	return anchorsflag;
    }

    /**
     * setter method for anchorsflag
     *
     * @param markers  a boolean value that determines if begin and end tags
     *                 are kept in the result
     */
    public final void setanchorsFlag(String markers) {
	if (markers.equalsIgnoreCase("true"))
	    anchorsflag = true;
	else
	    anchorsflag = false;
    }

    /**
     * setter method for the beginning anchor for this scrape    
     *
     * @param begin  anchor for the beginning of this scrape
     *
     */
    public final void setBegin(String begin) {
      this.begin = begin;
    }

    /**
     * getter method for the beginning anchor for this scrape
     *
     * @return the begin anchor for this scrape
     *
     */
    public final String getBegin() {
	return begin;
    }

    /**
     * setter method for the ending anchor for this scrape
     *
     * @param end  anchor for the end of this scrape
     */
    public final void setEnd(String end) {
      this.end = end;
    }

    /**
     * getter method for the ending anchor for this scrape
     *
     * @return the end anchor for this scrpae
     *
     */
    public final String getEnd() {
	return end;
    }

    /**
     * setter method for result
     *
     * @param result  the result of the scrape with this begin and end
     *
     */
    public final void setResult(String result) {
	this.result.setLength(0); // make sure that result is empty
	this.result.append(result);
    }

    /**
     * getter method for result
     *
     * @return the result of the scrape with this begin and end
     *
     */
    public final String getResult() {
	return result.toString();
    }
}
