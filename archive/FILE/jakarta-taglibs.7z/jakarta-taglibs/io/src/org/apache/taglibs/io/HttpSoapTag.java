/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.TagSupport;

/** A helper JSP Custom tag which makes a SOAP HTTP POST request.
  *
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public class HttpSoapTag extends HttpTag {

    /** The SOAPAction used */
    private String soapAction;
    
    /** The content type used */
    private String contentType = "text/xml";
    
    
    public HttpSoapTag() {
        setAction( "POST" );
    }

    // Properties
    //-------------------------------------------------------------------------                    
    public void setSOAPAction(String soapAction) {
        this.soapAction = soapAction;
    }

    // Implementation methods
    //-------------------------------------------------------------------------                    
    protected void configureConnection( URLConnection connection ) throws IOException {
        super.configureConnection( connection );
        connection.setRequestProperty( "Content-Type", "text/xml" );
        connection.setRequestProperty( "SOAPAction", soapAction );
    }
}
