/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.Tag;

/** A pipe tag can be given some input and it pipes to either its standard output
  * or it can pipe to a parent PipeConsumer
  *
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public class PipeTag extends TransformerTagSupport {

    public PipeTag() {
    }
    
    /** Pipe the input to the output unless my parent is a consumer
      * in which case I'll pass my input into my parent PipeConsumer
      */
    protected void transform(
        Reader reader, 
        Writer writer
    ) throws IOException, JspException {
        Tag parent = getParent();
        if ( parent instanceof PipeConsumer ) {
            PipeConsumer consumer = (PipeConsumer) parent;
            consumer.setReader( reader );
        }
        else {
            PipeHelper.pipe( reader, writer );
        }
    }
}    
