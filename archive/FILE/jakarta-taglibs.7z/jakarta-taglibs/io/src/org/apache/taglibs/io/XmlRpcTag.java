/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.servlet.ServletContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.TagSupport;

/** A helper JSP Custom tag which makes a SOAP HTTP POST request.
  *
  * @author <a href="mailto:james.strachan@metastuff.com">James Strachan</a>
  * @version $Revision: 216774 $
  */
public class XmlRpcTag extends HttpTag {

    protected static final String HOST_NAME = getHostName();
    
    /** The userAgent used */
    private String userAgent = "jakarta:io-tags/1.0";
    
    /** The host */
    private String host = HOST_NAME;
    
    /** The content type used */
    private String contentType = "text/xml";
    
    
    public XmlRpcTag() {
        setAction( "POST" );
    }

    // Properties
    //-------------------------------------------------------------------------                    
    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }

    // Implementation methods
    //-------------------------------------------------------------------------                    
    protected void configureConnection( URLConnection connection ) throws IOException {
        super.configureConnection( connection );
        connection.setRequestProperty( "Content-Type", "text/xml" );
        connection.setRequestProperty( "User-Agent", userAgent );
        connection.setRequestProperty( "Host", pageContext.getRequest().getServerName() );
    }

    /** @return the host name of the current JVM */
    protected static String getHostName() {
        String answer = null;
        try {
            InetAddress address = InetAddress.getLocalHost();
            if ( address != null ) {
                answer = address.getHostName();
                if ( answer == null || answer.length() <= 0 ) {
                    answer = address.getHostAddress();
                }
                
            }
        }
        catch (Exception e) {
            if ( WARN ) {
                System.out.println( "Couldn't resolve hostname" + e );
                e.printStackTrace();
            }
        }
        return ( answer != null ) ? answer : "localhost";
    }
    
}
