/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>group</b>, used to output the value for a single
 * parenthesized group within a single match.
 * <p>
 * The parenthesized group <b>number</b> attribute must be set.
 * <p>
 * Must be nested inside a <b>match</b> tag.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;group&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.GroupTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;empty&lt;/bodycontent&gt;
 * &lt;info&gt;Get the value of a single parenthesized group within a single match.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;number&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see MatchTag
 *
 * @author Glenn Nielsen
 */

public class GroupTag extends TagSupport
{
    private int number = 0;

    /**
     * Method called at end of Tag to output group value
     *
     * @return EVAL_PAGE
     */
    public final int doEndTag() throws JspException
    {
	MatchTag mt = null;
	try {
	    mt = (MatchTag)this.findAncestorWithClass(this,
		Class.forName("org.apache.taglibs.regexp.MatchTag"));
	} catch(Exception e) {
	}
	if( mt == null )
	    throw new JspException("regexp group tag could not find a parent match tag.");

	String value = mt.getGroup(number);

	try {
	    pageContext.getOut().write(value);
	} catch(Exception e) {
	    throw new JspException("IO Error: " + e.getMessage());
	}

	return EVAL_PAGE;
    }

    /*
     * Set the required attribute <b>number</b> to the
     * parenthesized group number to get from match.
     *
     * @param int parenthesized match group number
     */
    public final void setNumber(int number)
    {
	this.number = number;
    }

}
