/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.regexp;

import java.util.*;
import org.apache.oro.text.*;
import org.apache.oro.text.perl.*;
import org.apache.oro.text.regex.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

/**
 * JSP Tag <b>substitute</b>, used to perform global
 * substitution of the provided text.
 * <p>
 * Outputs the new text with substitutions.
 * <p>
 * The attribute <b>regexp</b> must be set to the id of a <b>regexp</b>
 * tag and the <b>text</b> attribute must be set to the id of a
 * <b>text</b> tag.
 * <p>
 * JSP Tag Lib Descriptor
 * <p><pre>
 * &lt;name&gt;substitute&lt;/name&gt;
 * &lt;tagclass&gt;org.apache.taglibs.regexp.SubstituteTag&lt;/tagclass&gt;
 * &lt;bodycontent&gt;JSP&lt;/bodycontent&gt;
 * &lt;info&gt;Uses the regexp to perform substitutions on the text.&lt;/info&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;regexp&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 *   &lt;attribute&gt;
 *     &lt;name&gt;text&lt;/name&gt;
 *     &lt;required&gt;true&lt;/required&gt;
 *     &lt;rtexprvalue&gt;false&lt;/rtexprvalue&gt;
 *   &lt;/attribute&gt;
 * </pre>
 *
 * @see RegexpTag
 * @see TextTag
 * @see RegexpData
 * @see TextData
 *
 * @author Glenn Nielsen
 */

public class SubstituteTag extends TagSupport
{
    private String regexpid = null;
    private String textid = null;

    /**
     * Uses the regexp to perform substitutions on the text,
     * then outputs the text.
     *
     * @return EVAL_BODY
     */
    public final int doEndTag() throws JspException
    {
	TextData td = (TextData)pageContext.getAttribute(textid,PageContext.PAGE_SCOPE);
	if( td == null )
	    throw new JspException(
		"regexp tag substitute could not find text tag with id: " +
		textid);
        RegexpData rd = (RegexpData)pageContext.getAttribute(regexpid,PageContext.PAGE_SCOPE);
        if( rd == null )
            throw new JspException(
                "regexp tag substitute could not find regexp tag with id: " +
                regexpid);

	Perl5Util perl = new Perl5Util(rd.getPatternCache());
	String out = perl.substitute(rd.getRegexp(),td.getText());

	try {
	    pageContext.getOut().write(out);
	} catch(Exception e) {
	    throw new JspException("IO Error: " + e.getMessage());
	}

	return EVAL_PAGE;
    }

    /*
     * Set the required attribute <b>regexp</b>
     *
     * @param String name of regexp script variable
     */
    public final void setRegexp(String str)
    {   
	regexpid = str;
    }

    /*
     * Set the required attribute <b>text</b>
     *
     * @param String name of text script variable
     */
    public final void setText(String str)
    {               
        textid = str;
    }

}
