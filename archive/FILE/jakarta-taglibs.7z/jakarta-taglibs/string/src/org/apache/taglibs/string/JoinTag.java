/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import javax.servlet.jsp.JspException;
import org.apache.commons.lang.StringUtils;

/**
 * Joins the elements of the provided array.
 * A separator may be passed in to put between each element.
 *
 * <dl>
 * <dt>items</dt><dd>
 *             Array of elements to be joined.
 * </dd>
 * <dt>separator</dt><dd>
 *             Separator string to be used.
 * </dd>
 * </dl>
 * 
 * @author Felipe Leme (felipeal at apache dot org)
 */
public class JoinTag extends StringTagSupport {

  private String separator;
  private Object[] items;

  public JoinTag() {
    super();
  }

  /**
   * Define the elements to be joined.
   *
   * @param items elements to be joined
   */
  public void setItems(Object[] items) {
    this.items = items;
  }


  /**
   * Set the separator to be used.
   *
   * @param separator separator to be used
   */
  public void setSeparator(String separator) {
    this.separator = separator;
  }

  public String changeString(String text) throws JspException {
    return this.separator == null ?
      StringUtils.join( this.items ) :
      StringUtils.join( this.items, this.separator );
  }

  public void initAttributes() {
    this.separator = null;
    this.items = null;
  }

}
