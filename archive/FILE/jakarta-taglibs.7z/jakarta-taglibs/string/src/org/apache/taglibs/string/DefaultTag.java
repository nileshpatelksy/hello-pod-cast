/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import javax.servlet.jsp.JspException;

/**
 * If the body String is a particular value, then output 
 * a default value, else output the body String.
 * The major use of this is to convert 'null' into an 
 * empty String.
 *
 * <dl>
 * <dt>value</dt><dd>
 *             Value to be equal to.
 *             Default is the string: "null".
 * </dd>
 * <dt>default</dt><dd>
 *             Value to place if body is equal to value field.
 *             Default is an empty String.
 * </dd>
 * </dl>
 * 
 * @author bayard@generationjava.com
 */
public class DefaultTag extends StringTagSupport {

    private String defaultValue;
    private String value;

    public DefaultTag() {
        super();
    }

    /**
     * Get the value property
     *
     * @return String property
     */
    public String getValue() {
        return this.value;
    }

    /**
     * Set the value property
     *
     * @param value String property
     */
    public void setValue(String value) {
        this.value = value;
    }


    /**
     * Get the default property
     *
     * @return String property
     */
    public String getDefault() {
        return this.defaultValue;
    }

    /**
     * Set the default property
     *
     * @param default String property
     */
    public void setDefault(String defaultValue) {
        this.defaultValue = defaultValue;
    }



    public String changeString(String text) throws JspException {
        if( (""+text).equals(this.value) ) {
            return this.defaultValue;
        } else {
            return text;
        }
    }

    public void initAttributes() {

        this.value = "null";

        this.defaultValue = "";

    }

}
