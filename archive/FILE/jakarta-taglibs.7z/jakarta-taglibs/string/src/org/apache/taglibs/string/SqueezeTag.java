/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import javax.servlet.jsp.JspException;
import org.apache.commons.lang.CharSetUtils;

/**
 * Squeeze any characters from the body that match 
 * characters specified in the Set. Squeezing means that 
 * if it finds two adjoining characters that are the same, 
 * they are replaced with a single one of the characters.
 * The syntax of a Set is described in the CountTag javadoc.
 *
 * <dl>
 * <dt>set</dt><dd>
 *             Character Set to look for.
 *             Required.
 * </dd>
 * </dl>
 * 
 * @author bayard@generationjava.com
 */
public class SqueezeTag extends StringTagSupport {

    private String set;

    public SqueezeTag() {
        super();
    }

    /**
     * Get the set property
     *
     * @return String property
     */
    public String getSet() {
        return this.set;
    }

    /**
     * Set the set property
     *
     * @param set String property
     */
    public void setSet(String set) {
        this.set = set;
    }



    public String changeString(String text) throws JspException {
        return CharSetUtils.squeeze(text, set);
    }

    public void initAttributes() {

        this.set = null;

    }

}
