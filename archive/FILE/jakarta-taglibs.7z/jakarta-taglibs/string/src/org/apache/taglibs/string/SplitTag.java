/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import javax.servlet.jsp.JspException;
import org.apache.commons.lang.StringUtils;

/**
 * Splits the provided text into an array, separators specified.
 * The separator is not included in the returned String array and adjacent separators are treated
 * as one separator.
 *
 * <dl>
 * <dt>separator</dt><dd>
 *             Separator string to be used.
 * </dd>
 * </dl>
 * 
 * @author Felipe Leme (felipeal at apache dot org)
 */
public class SplitTag extends StringTagSupport {

  private String separator;

  public SplitTag() {
    super();
  }

  /**
   * Set the separator to be used.
   *
   * @param separator separator to be used
   */
  public void setSeparator(String separator) {
    this.separator = separator;
  }

  public String changeString(String text) throws JspException {
    throw new JspException( "INTERNAL ERROR: operation not supported" );
  }

  public Object evaluateString(String text) throws JspException {
    return StringUtils.split( text, this.separator );
  }

  public void initAttributes() {
    this.separator = null;
  }

}
