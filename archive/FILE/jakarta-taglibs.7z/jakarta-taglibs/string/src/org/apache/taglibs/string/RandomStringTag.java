/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

import javax.servlet.jsp.JspException;


// TODO: Decide if set should be a CharSet.
/// Note: There is a lot of tied logic between this class and 
///       the RandomStringUtils random methods. Understand how all the 
///       overloading works in RandomStringUtils before tackling this 
///       class.

/**
 * Create a random string. It can create an ascii string,
 * a numeric string, an alphanumeric string, and a unicode
 * string. The size of the string may be specified, as can a
 * start and end character. Lastly, a set of characters to use
 * may be passed in.
 *
 * <dl>
 * <dt>count</dt><dd>
 *            Number of characters to generate.
 *            Required.
 * </dd>
 * <dt>start</dt><dd>
 *            Start of range of characters to generate from.
 *            Linked to type attribute.
 * </dd>
 * <dt>end</dt><dd>
 *            End of range of characters to generate from.
 *            Linked to type attribute.
 * </dd>
 * <dt>type</dt><dd>
 *            Type of random-string. One of: numeric | alphanumeric | alphabet | unicode.
 *            Default value is to unicode.
 * </dd>
 * </dl>
 *
 * @author bayard@generationjava.com
 */
public class RandomStringTag extends StringTagSupport {
    static public String NUMERIC = "numeric";
    static public String ALPHANUMERIC = "alphanumeric";
    static public String ALPHABET = "alphabet";
    static public String UNICODE = "unicode";
    private String count;
    private String start;
    private String end;
    private String type;

    public RandomStringTag() {
        super();
    }

    /**
     * Get the count property
     *
     * @return String property
     */
    public String getCount() {
        return this.count;
    }

    /**
     * Set the count property
     *
     * @param with String property
     */
    public void setCount(String count) {
        this.count = count;
    }

    /**
     * Get the start property
     *
     * @return String property
     */
    public String getStart() {
        return this.start;
    }

    /**
     * Set the start property
     *
     * @param start String property
     */
    public void setStart(String start) {
        this.start = start;
    }

    /**
     * Get the end property
     *
     * @return String property
     */
    public String getEnd() {
        return this.end;
    }

    /**
     * Set the end property
     *
     * @param end String property
     */
    public void setEnd(String end) {
        this.end = end;
    }

    /**
     * Get the type property
     *
     * @return String property
     */
    public String getType() {
        return this.type;
    }

    /**
     * Set the type property
     *
     * @param with String property
     */
    public void setType(String type) {
        this.type = type;
    }

    public String changeString(String text) throws JspException {
        int st = 0; // real start
        int ed = 0; // real end
        int ct = 0; // real count
        boolean letters = false;
        boolean numbers = false;

        letters = ALPHABET.equals(type);
        numbers = NUMERIC.equals(type);

        if (ALPHANUMERIC.equals(type)) {
            letters = true;
            numbers = true;
        }

        char[] setChrs = null;

        if (!StringUtils.isBlank(text)) {
            setChrs = text.toCharArray();
        }

        if (!StringUtils.isEmpty(start)) {
            try {
                if (NumberUtils.isNumber(start)) {
                    st = NumberUtils.createNumber(start).intValue();
                } else {
                    st = (int) start.charAt(0);
                }
            } catch (NumberFormatException nfe) {
            } catch (NullPointerException npe) { // easiest way to code it
            }
        }

        if (!StringUtils.isEmpty(end)) {
            try {
                if (NumberUtils.isNumber(end)) {
                    ed = NumberUtils.createNumber(end).intValue();
                } else {
                    ed = (int) end.charAt(0);
                }
            } catch (NumberFormatException nfe) {
                nfe.printStackTrace();
            } catch (NullPointerException npe) { // easiest way to code it
                npe.printStackTrace();
            }
        }

        // if a set of chars is passed in, we need to be very cautions with its boundaries
        // NOTE: these checkings should be done by RandomStringUtils
		if ( (setChrs != null) ) {
			if ( st > setChrs.length-1 ) {
				st =0;
			}
			if ( ed == 0 || ed > setChrs.length-1 ) {
				ed = setChrs.length-1;
			}

        }
        
        try {
            ct = NumberUtils.createNumber(count).intValue();
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        } catch (NullPointerException npe) { // easiest way to code it
            npe.printStackTrace();
        }

		String randomString = null;
		try {
	        randomString = RandomStringUtils.random(ct, st, ed, letters, numbers, setChrs);
		} catch ( Exception exc ) {
			// in the worst case scenario, be nice and return a random String....
			if ( letters && numbers ) {
				randomString = RandomStringUtils.randomAlphanumeric( ct );
			} else if ( letters ) {
				randomString = RandomStringUtils.randomNumeric( ct );
			} else if ( numbers ) {
				randomString = RandomStringUtils.randomNumeric( ct );
			} else {
				randomString = RandomStringUtils.random( ct );
			}
			StringBuffer msg = new StringBuffer();
			msg.append( "Exception on RandomStringTag: " + exc  );
			msg.append("\nCT: " + ct);
			msg.append("\nST: " + st);
			msg.append("\nED: " + ed);
			msg.append("\nletters: " + letters);
			msg.append("\nnumbers: " + numbers);
			msg.append("\nset: " + (setChrs == null ? "null" : ""+setChrs.length + " characters") );
			msg.append("\nreturning " + randomString );
			System.err.println( msg.toString());
		}
		
		// TODO: RandomString is not working if body is set...
		/*
		System.err.println(">>>" + randomString + "<<<" );
		*/		
		return randomString;
    }

    public void initAttributes() {
        this.count = null;
        this.start = null;
        this.end = null;
        this.type = UNICODE;
    }

}
