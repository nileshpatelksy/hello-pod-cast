/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Copied from GenerationJava Core Library.
//package com.generationjava.util;

package org.apache.taglibs.string.util;

/**
 * Find the Soundex of a string. Needs internationalisation in a 
 * future release.
 *
 * @author bayard@generationjava.com
 * @version 0.4, 20010812
 */
public class Soundex {

    static public final char[] US_ENGLISH_MAPPING =
        "01230120022455012623010202".toCharArray();

    static public final Soundex US_ENGLISH = new Soundex();
    
    private char[] soundexMapping;

    public Soundex() {
        this(US_ENGLISH_MAPPING);
    }

    public Soundex(char[] mapping) {
        this.soundexMapping = mapping;
    }

    /**
     * Get the SoundEx value of a string.
     * This implementation is taken from the code-snippers on 
     * http://www.sourceforge.net/
     */
    public String soundex(String str) {
        char out[] = { '0', '0', '0', '0' };
        char last, mapped;
        int incount = 1, count = 1;
        out[0] = Character.toUpperCase( str.charAt(0) );
        last = getMappingCode( str.charAt(0) );
        while( (incount < str.length() ) && 
               (mapped = getMappingCode(str.charAt(incount++))) != 0 &&
               (count < 4) )
        {
            if( (mapped != '0') && (mapped != last) ) {
                out[count++] = mapped;
            }
            last = mapped;
        }
        return new String(out);
    }

    /**
     * Used internally by the SoundEx algorithm.
     */
    private char getMappingCode(char c) {
        if( !Character.isLetter(c) ) {
            return 0;
        } else {
            return soundexMapping[Character.toUpperCase(c) - 'A'];
        }
    }

}
