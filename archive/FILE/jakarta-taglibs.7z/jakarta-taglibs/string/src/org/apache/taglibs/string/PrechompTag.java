/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import javax.servlet.jsp.JspException;
import org.apache.commons.lang.StringUtils;

/**
 * Remove everything up until a specified delimiter, and
 * that specified delimiter from the start of a String.
 *
 * <dl>
 * <dt>delimiter</dt><dd>
 *             Character to remove before.
 *             Default is a newline character.
 * </dd>
 * </dl>
 * 
 * @author bayard@generationjava.com
 */
public class PrechompTag extends StringTagSupport {

    private String delimiter;

    public PrechompTag() {
        super();
    }

    /**
     * Get the delimiter property
     *
     * @return String property
     */
    public String getDelimiter() {
        return this.delimiter;
    }

    /**
     * Set the delimiter property
     *
     * @param delimiter String property
     */
    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }



    public String changeString(String text) throws JspException {
		return StringUtils.substringAfter(text, delimiter);    	
    }

    public void initAttributes() {
        this.delimiter = "\n";
    }


}
