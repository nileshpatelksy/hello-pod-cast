/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import javax.servlet.jsp.JspException;

/**
 * Replace a specified substring with another string.
 * A number of times may be specified to say how many times 
 * to replace the substring.
 *
 * <dl>
 * <dt>replace</dt><dd>
 *             Value to find to replace.
 *             Required.
 * </dd>
 * <dt>with</dt><dd>
 *             Value to replace with.
 *             Required.
 * </dd>
 * <dt>count</dt><dd>
 *             Number of times to replace.
 *             Default is all matches.
 * </dd>
 * <dt>newlineToken</dt><dd>
 *             Token to use as a newline.
 *             This gets around the pain of haivng a literal newline in the jsp.
 *             By default this is ignored.
 * </dd>
 * <dt>carriageToken</dt><dd>
 *             Token to use as a carriage return.
 *             This gets around the pain of haivng a literal carriage return 
 *             in the jsp. 
 *             By default this is ignored.
 * </dd>
 * </dl>
 * 
 * @author bayard@generationjava.com
 */
public class ReplaceTag extends StringTagSupport {

    private String count;
    private String replace;
    private String with;
    private String newlineToken;
    private String carriageToken;

    public ReplaceTag() {
        super();
    }

    /**
     * Get the replace property
     *
     * @return String property
     */
    public String getReplace() {
        return this.replace;
    }

    /**
     * Set the replace property
     *
     * @param replace String property
     */
    public void setReplace(String replace) {
        this.replace = replace;
    }

    /**
     * Get the newlineToken property
     *
     * @return String property
     */
    public String getNewlineToken() {
        return this.newlineToken;
    }

    /**
     * Set the newlineToken property
     *
     * @param newlineToken String property
     */
    public void setNewlineToken(String newlineToken) {
        this.newlineToken = newlineToken;
    }

    /**
     * Get the carriageToken property
     *
     * @return String property
     */
    public String getCarriageToken() {
        return this.carriageToken;
    }

    /**
     * Set the carriageToken property
     *
     * @param carriageToken String property
     */
    public void setCarriageToken(String carriageToken) {
        this.carriageToken = carriageToken;
    }


    /**
     * Get the with property
     *
     * @return String property
     */
    public String getWith() {
        return this.with;
    }

    /**
     * Set the with property
     *
     * @param with String property
     */
    public void setWith(String with) {
        this.with = with;
    }


    /**
     * Get the count property
     *
     * @return String property
     */
    public String getCount() {
        return this.count;
    }

    /**
     * Set the count property
     *
     * @param count String property
     */
    public void setCount(String count) {
        this.count = count;
    }



    public String changeString(String text) throws JspException {
        String repl = replace;
        String wit = with;
        if(this.carriageToken != null) {
            repl = StringUtils.replace(replace, this.carriageToken, "\r");
            wit = StringUtils.replace(with, this.carriageToken, "\r");
        }
        if(this.newlineToken != null) {
            repl = StringUtils.replace(replace, this.newlineToken, "\n");
            wit = StringUtils.replace(with, this.newlineToken, "\n");
        }
        int ct = -1;
        if(count != null) {
            ct = NumberUtils.stringToInt(count);
        }
        return StringUtils.replace(text, repl, wit, ct);
    }

    public void initAttributes() {

        this.replace = null;

        this.with = null;

        this.count = null;

        this.newlineToken = null;
        this.carriageToken = null;

    }

}
