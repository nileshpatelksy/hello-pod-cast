/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.taglibs.string;

import javax.servlet.jsp.JspException;
import org.apache.commons.lang.StringUtils;

/**
 * Get a String that is nested between an open and closing 
 * substring.
 *
 * <dl>
 * <dt>open</dt><dd>
 *             Index to start substring at.
 *             Required.
 * </dd>
 * <dt>close</dt><dd>
 *             Index to stop substring before.
 *             Default is to be the last index.
 * </dd>
 * </dl>
 * 
 * @author bayard@generationjava.com
 */
public class NestedStringTag extends StringTagSupport {

    private String close;
    private String open;

    public NestedStringTag() {
        super();
    }

    /**
     * Get the open property
     *
     * @return String property
     */
    public String getOpen() {
        return this.open;
    }

    /**
     * Set the open property
     *
     * @param open String property
     */
    public void setOpen(String open) {
        this.open = open;
    }


    /**
     * Get the close property
     *
     * @return String property
     */
    public String getClose() {
        return this.close;
    }

    /**
     * Set the close property
     *
     * @param close String property
     */
    public void setClose(String close) {
        this.close = close;
    }



    public String changeString(String text) throws JspException {
        if(close == null) {
            close = open;
        }
		return StringUtils.substringBetween(text, open, close);
    }

    public void initAttributes() {

        this.open = null;

        this.close = null;

    }

}
