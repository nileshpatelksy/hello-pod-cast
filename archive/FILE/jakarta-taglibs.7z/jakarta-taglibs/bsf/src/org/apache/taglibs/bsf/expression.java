/*
 * Copyright 1999,2004 The Apache Software Foundation.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.taglibs.bsf ;

import javax.servlet.jsp.* ;
import javax.servlet.jsp.tagext.* ;
import java.io.IOException ;

import org.apache.bsf.* ;

public class expression implements BodyTag
{
    protected Tag          parent ;
    protected BodyContent  bodyOut ;
    protected PageContext  pageContext ;
    protected String       language ;

    public void setLanguage(String value)           { language = value ; };
    public void setParent(Tag parent)               { this.parent = parent ; };
    public Tag  getParent()                         { return( this.parent ); };
    public void doInitBody()  throws JspException   { };
    public int  doAfterBody() throws JspException   { return 0; };
    public void release()                           { };
    public void setBodyContent(BodyContent bodyOut) { this.bodyOut = bodyOut;};
    public int  doStartTag() throws JspException    { return(EVAL_BODY_TAG);};

    public void setPageContext(PageContext pageContext) { 
        this.pageContext = pageContext ;
    };

    private void register( BSFManager mgr, String name, Object bean ) 
                     throws Exception {
	if ( bean == null ) return ;
        try {
	    mgr.declareBean( name, bean, bean.getClass() );
	}
	catch( Exception e ) {
	    throw e ;
	}
    };

    public int doEndTag() throws JspException {
        try {
            JspWriter out = pageContext.getOut();
	    if ( bodyOut == null ) return( EVAL_PAGE );

            BSFManager mgr  = new BSFManager ();
            BSFEngine  BSFengine = mgr.loadScriptingEngine (language);

            try {
	        register( mgr, "request"    , pageContext.getRequest() );
		register( mgr, "response"   , pageContext.getResponse() );
		register( mgr, "pageContext", pageContext );
		register( mgr, "application", pageContext.getServletContext() );
		register( mgr, "out"        , out );
		register( mgr, "config"     , pageContext.getServletConfig() );
		register( mgr, "page"       , pageContext.getPage() );
		register( mgr, "exception"  , pageContext.getException() );
		register( mgr, "session"    , pageContext.getSession() );
	    } catch( Exception e ) {
	        out.println( e.toString() );
	        e.printStackTrace();
	    }

	    Object result ;
	    result = BSFengine.eval ("<unknown>", 0, 0, bodyOut.getString() );
	    if ( result != null )
	        out.println( result.toString() );
	} catch( Exception e ) {
	    System.out.println( e.toString() );
	    e.printStackTrace();
	    // throw new JspException( e.toString() );
	}
        return( EVAL_PAGE );
    };
}
