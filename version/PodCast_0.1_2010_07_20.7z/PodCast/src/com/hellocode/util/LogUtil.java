package com.hellocode.util;

public class LogUtil {

}
