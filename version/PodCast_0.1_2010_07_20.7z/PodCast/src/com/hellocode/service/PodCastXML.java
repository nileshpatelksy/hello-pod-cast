package com.hellocode.service;

import java.util.ArrayList;

import com.hellocode.model.PodCastURL;

public final class PodCastXML {
	private ArrayList<PodCastURL> podCasts = new ArrayList<PodCastURL>();
	
	/**
	 * save all data to file
	 */
	public void persist(){
		
	}
}
