package com.hellocode.model;

public class XMLPodCastURL {
	 String title;
	 String author;
	 String link;
	 String summary;
	 String subtitle;
	 String copyright;
	 String language;
	 String ownerName;
	 String ownerEmail;
	 String imageURL;
	 public void setTitle(String title) {
		this.title = title;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	String category;

	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public String getLink() {
		return link;
	}

	public String getSummary() {
		return summary;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public String getCopyright() {
		return copyright;
	}

	public String getLanguage() {
		return language;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public String getOwnerEmail() {
		return ownerEmail;
	}

	public String getImageURL() {
		return imageURL;
	}

	public String getCategory() {
		return category;
	}

}
