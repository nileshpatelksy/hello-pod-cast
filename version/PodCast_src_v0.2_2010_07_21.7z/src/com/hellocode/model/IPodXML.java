package com.hellocode.model;


public interface IPodXML {

	int reFreshURL();

}